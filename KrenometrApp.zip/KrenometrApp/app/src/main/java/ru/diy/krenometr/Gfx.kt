package ru.diy.krenometr

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt

val DEG = (PI / 180.0).toFloat()
val PIF = PI.toFloat()

/** Цвета — как в прошивке (iOS-палитра). */
object C {
    val BG = Color.rgb(0, 0, 0)
    val WHITE = Color.rgb(255, 255, 255)
    val GRAY = Color.rgb(142, 142, 147)
    val GRAY2 = Color.rgb(99, 99, 102)
    val GRAY4 = Color.rgb(58, 58, 60)
    val TRACK = Color.rgb(44, 44, 46)
    val CARD = Color.rgb(28, 28, 30)
    val GREEN = Color.rgb(48, 209, 88)
    val YELLOW = Color.rgb(255, 214, 10)
    val ORANGE = Color.rgb(255, 159, 10)
    val RED = Color.rgb(255, 69, 58)
    val BLUE = Color.rgb(10, 132, 255)
    val TEAL = Color.rgb(100, 210, 255)

    val CAR_BLUE = Color.rgb(60, 88, 126)
    val CAR_DARK = Color.rgb(38, 56, 82)
    val CAR_GLASS = Color.rgb(16, 20, 28)
    val CAR_TIRE = Color.rgb(50, 50, 54)
    val CAR_RIM = Color.rgb(176, 178, 184)
    val CAR_RIM2 = Color.rgb(118, 120, 126)
    val CAR_TRIM = Color.rgb(30, 30, 34)
    val CAR_BOX = Color.rgb(60, 60, 64)
    val CAR_BOX_HL = Color.rgb(96, 96, 102)
    val CAR_CHROME = Color.rgb(200, 204, 212)
    val CAR_TAIL = Color.rgb(220, 50, 42)
    val CAR_AMBER = Color.rgb(255, 150, 40)
    val PLATE = Color.rgb(222, 222, 228)
    val HEADLIGHT = Color.rgb(230, 236, 246)

    val TL_AMBER = Color.rgb(245, 166, 35)
    val TL_HOT = Color.rgb(240, 90, 40)
    val TL_RED = Color.rgb(214, 40, 40)
    val TL_BLUE = Color.rgb(30, 140, 230)

    val AH_SKY = Color.rgb(26, 104, 196)
    val AH_GND = Color.rgb(128, 82, 42)
}

/** Размеры шрифтов в логических единицах (круг 240×240, как в прошивке). */
object F {
    const val TINY = 12f
    const val SMALL = 15f
    const val MED = 21f
    const val VAL = 27f
    const val BIG = 44f
    const val HUGE = 64f
}

const val AL_LEFT = 0
const val AL_CENTER = 1
const val AL_RIGHT = 2

/**
 * Примитивы рисования в логических координатах 240×240 — те же, что в прошивке
 * (fillCircleAA, ringAA, lineAA, arcAA, rrectAA, polyAA, text). Углы — в радианах.
 */
class Gfx {
    lateinit var c: Canvas

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private val path = Path()

    private fun paint(p: Paint, color: Int, alpha: Int): Paint {
        p.color = color
        if (alpha < 255) p.alpha = alpha * Color.alpha(color) / 255
        return p
    }

    fun circle(x: Float, y: Float, r: Float, color: Int, alpha: Int = 255) {
        c.drawCircle(x, y, r, paint(fill, color, alpha))
    }

    fun ring(x: Float, y: Float, r: Float, w: Float, color: Int, alpha: Int = 255) {
        stroke.strokeWidth = w
        c.drawCircle(x, y, r, paint(stroke, color, alpha))
    }

    fun line(x0: Float, y0: Float, x1: Float, y1: Float, w: Float, color: Int, alpha: Int = 255) {
        stroke.strokeWidth = w
        c.drawLine(x0, y0, x1, y1, paint(stroke, color, alpha))
    }

    fun arc(cx: Float, cy: Float, r: Float, w: Float, a0: Float, a1: Float, color: Int, alpha: Int = 255) {
        val s = minOf(a0, a1)
        val e = maxOf(a0, a1)
        if (e - s < 0.001f) {
            circle(cx + r * kotlin.math.cos(s), cy + r * kotlin.math.sin(s), w / 2f, color, alpha)
            return
        }
        stroke.strokeWidth = w
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, s / DEG, (e - s) / DEG, false, paint(stroke, color, alpha))
    }

    fun rrect(cx: Float, cy: Float, hw: Float, hh: Float, rad: Float, ang: Float, color: Int, alpha: Int = 255) {
        val rotated = abs(ang) > 1e-4f
        if (rotated) { c.save(); c.rotate(ang / DEG, cx, cy) }
        rect.set(cx - hw, cy - hh, cx + hw, cy + hh)
        val r = minOf(rad, hw, hh)
        c.drawRoundRect(rect, r, r, paint(fill, color, alpha))
        if (rotated) c.restore()
    }

    fun rrOutline(cx: Float, cy: Float, hw: Float, hh: Float, r: Float, w: Float, color: Int) {
        stroke.strokeWidth = w
        rect.set(cx - hw, cy - hh, cx + hw, cy + hh)
        c.drawRoundRect(rect, r, r, paint(stroke, color, 255))
    }

    /** Многоугольник из пар x, y. */
    fun poly(color: Int, vararg xy: Float) = polyA(color, 255, *xy)

    fun polyA(color: Int, alpha: Int, vararg xy: Float) {
        path.reset()
        path.moveTo(xy[0], xy[1])
        var i = 2
        while (i + 1 < xy.size) { path.lineTo(xy[i], xy[i + 1]); i += 2 }
        path.close()
        c.drawPath(path, paint(fill, color, alpha))
    }

    /** Текст: y — базовая линия, как в прошивке. */
    fun text(x: Float, y: Float, s: String, size: Float, color: Int, align: Int = AL_CENTER, alpha: Int = 255) {
        txt.textSize = size
        txt.textAlign = when (align) {
            AL_LEFT -> Paint.Align.LEFT
            AL_RIGHT -> Paint.Align.RIGHT
            else -> Paint.Align.CENTER
        }
        c.drawText(s, x, y, paint(txt, color, alpha))
    }

    fun textWidth(s: String, size: Float): Float { txt.textSize = size; return txt.measureText(s) }

    /** Закраска области «по другую сторону» прямой: точка (px,py) на прямой, нормаль (nx,ny). */
    fun halfPlane(px: Float, py: Float, nx: Float, ny: Float, color: Int) {
        val tx = ny; val ty = -nx
        val big = 600f
        polyA(color, 255,
            px - tx * big, py - ty * big,
            px + tx * big, py + ty * big,
            px + tx * big + nx * big, py + ty * big + ny * big,
            px - tx * big + nx * big, py - ty * big + ny * big)
    }
}

/** Как fmtNum в прошивке: запятая и настоящий минус. */
fun fmtNum(v: Float, dec: Int, suffix: String = ""): String {
    var t = String.format(java.util.Locale.US, "%." + dec + "f", abs(v)).replace('.', ',')
    val scaled = (abs(v) * Math.pow(10.0, dec.toDouble()).toFloat()).roundToInt()
    if (v < 0 && scaled != 0) t = "−" + t
    return t + suffix
}

fun zone(v: Float, warn: Float, danger: Float): Int {
    val a = abs(v)
    return if (a >= danger) C.RED else if (a >= warn) C.YELLOW else C.GREEN
}
