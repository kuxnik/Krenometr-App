package ru.diy.krenometr

import android.graphics.Color
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Объёмная модель Pajero Sport (KH) для кренометра. Оси машины: X — вперёд, Y — влево, Z — вверх, дециметры.
 * Модель поворачивается сразу по крену и тангажу, поэтому на виде сзади виден и тангаж (крыша/днище),
 * а на виде сбоку — крен (колёса дальнего борта, крыша). Рисование — грани с отсечением задних и
 * сортировкой по глубине («алгоритм художника»), тон грани — от направления света.
 * Тот же код (числа и порядок) — в прошивке, функция car3d().
 */
object Car3D {
    class Face(val color: Int, val p: Array<FloatArray>, val inside: FloatArray)

    val faces: List<Face> by lazy { build() }

    private fun v(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)

    /** Шестигранник из «заднего» и «переднего» колец по 4 точки (низ-лево, низ-право, верх-право, верх-лево). */
    private fun hexa(out: MutableList<Face>, c: Int, r: Array<FloatArray>, f: Array<FloatArray>, colors: IntArray? = null) {
        val inside = FloatArray(3)
        for (q in r + f) for (i in 0..2) inside[i] += q[i] / 8f
        val quads = arrayOf(
            arrayOf(r[0], r[1], r[2], r[3]),          // зад
            arrayOf(f[0], f[3], f[2], f[1]),          // перед
            arrayOf(r[0], r[3], f[3], f[0]),          // левый борт
            arrayOf(r[1], f[1], f[2], r[2]),          // правый борт
            arrayOf(r[3], r[2], f[2], f[3]),          // верх
            arrayOf(r[0], f[0], f[1], r[1]))          // низ
        for (i in quads.indices) out.add(Face(colors?.get(i) ?: c, quads[i], inside))
    }

    /** Плоская деталь на грани (фонарь, номер, окно): чуть наружу, чтобы рисовалась поверх. */
    private fun decal(out: MutableList<Face>, c: Int, inside: FloatArray, vararg p: FloatArray) {
        out.add(Face(c, arrayOf(*p), inside))
    }

    private fun build(): List<Face> {
        val o = ArrayList<Face>()
        val body = C.CAR_BLUE; val glass = C.CAR_GLASS; val trim = C.CAR_TRIM
        // кузов: задняя часть до лобового стекла и капот
        hexa(o, body,
            arrayOf(v(-23.5f, 8.2f, 4.6f), v(-23.5f, -8.2f, 4.6f), v(-23.5f, -8.2f, 10.5f), v(-23.5f, 8.2f, 10.5f)),
            arrayOf(v(10f, 8.2f, 4.6f), v(10f, -8.2f, 4.6f), v(10f, -8.2f, 10.5f), v(10f, 8.2f, 10.5f)))
        hexa(o, body,
            arrayOf(v(10f, 8.2f, 4.6f), v(10f, -8.2f, 4.6f), v(10f, -8.2f, 10.5f), v(10f, 8.2f, 10.5f)),
            arrayOf(v(23.5f, 7.9f, 4.6f), v(23.5f, -7.9f, 4.6f), v(23.5f, -7.9f, 8.8f), v(23.5f, 7.9f, 8.8f)))
        // бамперы
        hexa(o, trim,
            arrayOf(v(-24.3f, 8.0f, 3.6f), v(-24.3f, -8.0f, 3.6f), v(-24.3f, -8.0f, 5.8f), v(-24.3f, 8.0f, 5.8f)),
            arrayOf(v(-22.8f, 8.0f, 3.6f), v(-22.8f, -8.0f, 3.6f), v(-22.8f, -8.0f, 5.8f), v(-22.8f, 8.0f, 5.8f)))
        hexa(o, trim,
            arrayOf(v(22.8f, 8.0f, 3.6f), v(22.8f, -8.0f, 3.6f), v(22.8f, -8.0f, 6.2f), v(22.8f, 8.0f, 6.2f)),
            arrayOf(v(24.5f, 7.6f, 3.6f), v(24.5f, -7.6f, 3.6f), v(24.5f, -7.6f, 6.2f), v(24.5f, 7.6f, 6.2f)))
        // салон: стёкла по бокам, спереди и сзади, крыша — цвета кузова
        hexa(o, glass,
            arrayOf(v(-22.6f, 7.9f, 10.5f), v(-22.6f, -7.9f, 10.5f), v(-21.6f, -7.0f, 17.2f), v(-21.6f, 7.0f, 17.2f)),
            arrayOf(v(9.5f, 7.9f, 10.5f), v(9.5f, -7.9f, 10.5f), v(-1.0f, -7.0f, 17.2f), v(-1.0f, 7.0f, 17.2f)),
            intArrayOf(glass, glass, glass, glass, body, body))
        val cabIn = floatArrayOf(-8f, 0f, 14f)
        // стойки: B и C с обеих сторон, рамка заднего стекла
        for (s in floatArrayOf(1f, -1f)) {
            val yb = 7.9f * s + 0.08f * s; val yt = 7.0f * s + 0.08f * s
            decal(o, body, cabIn, v(-6.6f, yb, 10.5f), v(-5.0f, yb, 10.5f), v(-5.3f, yt, 17.2f), v(-6.9f, yt, 17.2f))
            decal(o, body, cabIn, v(-22.6f, yb, 10.5f), v(-19.8f, yb, 10.5f), v(-19.4f, yt, 17.2f), v(-21.6f, yt, 17.2f))
        }
        // бокс на крыше
        hexa(o, C.CAR_BOX,
            arrayOf(v(-15f, 5.6f, 17.6f), v(-15f, -5.6f, 17.6f), v(-14.4f, -5.2f, 20.2f), v(-14.4f, 5.2f, 20.2f)),
            arrayOf(v(5.5f, 5.6f, 17.6f), v(5.5f, -5.6f, 17.6f), v(3.5f, -5.2f, 19.6f), v(3.5f, 5.2f, 19.6f)))
        // зеркала
        for (s in floatArrayOf(1f, -1f)) {
            val y0 = 7.9f * s; val y1 = 9.6f * s
            hexa(o, body,
                arrayOf(v(7.6f, y1, 11.0f), v(7.6f, y0, 11.0f), v(7.6f, y0, 12.4f), v(7.6f, y1, 12.4f)),
                arrayOf(v(8.6f, y1, 11.0f), v(8.6f, y0, 11.0f), v(8.6f, y0, 12.4f), v(8.6f, y1, 12.4f)))
        }
        // корма: фонари и номер; перед: фары и решётка
        val rearIn = floatArrayOf(-6f, 0f, 7.5f)
        val xr = -23.58f
        for (s in floatArrayOf(1f, -1f))
            decal(o, C.CAR_TAIL, rearIn, v(xr, 8.1f * s, 7.4f), v(xr, 5.4f * s, 7.4f), v(xr, 5.4f * s, 10.3f), v(xr, 8.1f * s, 10.3f))
        decal(o, C.PLATE, rearIn, v(xr, 2.6f, 6.2f), v(xr, -2.6f, 6.2f), v(xr, -2.6f, 7.6f), v(xr, 2.6f, 7.6f))
        val frontIn = floatArrayOf(16f, 0f, 6.5f)
        val xf = 23.58f
        for (s in floatArrayOf(1f, -1f))
            decal(o, C.HEADLIGHT, frontIn, v(xf, 7.6f * s, 7.2f), v(xf, 4.6f * s, 7.2f), v(xf, 4.6f * s, 8.6f), v(xf, 7.6f * s, 8.6f))
        decal(o, trim, frontIn, v(xf, 4.3f, 6.3f), v(xf, -4.3f, 6.3f), v(xf, -4.3f, 8.6f), v(xf, 4.3f, 8.6f))
        // колёса: шина-цилиндр (10 граней), диск и ступица на наружной стороне
        val n = 10
        for (wx in floatArrayOf(-14f, 14f)) for (s in floatArrayOf(1f, -1f)) {
            val yo = 9.0f * s; val yi = 6.4f * s; val r = 3.8f; val zc = 3.8f
            val wIn = floatArrayOf(wx, 7.7f * s, zc)
            val outer = Array(n) { i -> val a = 2 * PIF * i / n; v(wx + r * cos(a), yo, zc + r * sin(a)) }
            val inner = Array(n) { i -> val a = 2 * PIF * i / n; v(wx + r * cos(a), yi, zc + r * sin(a)) }
            o.add(Face(C.CAR_TIRE, outer, wIn))
            for (i in 0 until n) { val j = (i + 1) % n; o.add(Face(C.CAR_TIRE, arrayOf(outer[i], outer[j], inner[j], inner[i]), wIn)) }
            val yr = yo + 0.06f * s
            o.add(Face(C.CAR_RIM, Array(n) { i -> val a = 2 * PIF * i / n; v(wx + 2.5f * cos(a), yr, zc + 2.5f * sin(a)) }, wIn))
            o.add(Face(C.CAR_RIM2, Array(6) { i -> val a = 2 * PIF * i / 6; v(wx + 0.9f * cos(a), yr + 0.04f * s, zc + 0.9f * sin(a)) }, wIn))
        }
        return o
    }

    const val VIEW_REAR = 0
    const val VIEW_SIDE = 1

    private class Drawn(val depth: Float, val color: Int, val xy: FloatArray)
    private val buf = ArrayList<Drawn>(160)

    private fun shade(c: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1.3f)
        return Color.rgb(min(255f, Color.red(c) * k).toInt(), min(255f, Color.green(c) * k).toInt(), min(255f, Color.blue(c) * k).toInt())
    }

    /**
     * Нарисовать машину. view — сзади или сбоку (мордой вправо, камера с правого борта);
     * (cx, cy) — куда на экране попадает центр машины, k — пикселей на дециметр.
     * roll > 0 — правый борт ниже, pitch > 0 — нос вверх (как в прошивке).
     */
    fun draw(g: Gfx, view: Int, cx: Float, cy: Float, k: Float, rollDeg: Float, pitchDeg: Float) {
        val cr = cos(rollDeg * DEG); val sr = sin(rollDeg * DEG)
        val cp = cos(pitchDeg * DEG); val sp = sin(pitchDeg * DEG)
        val e = (if (view == VIEW_REAR) 13f else 9f) * DEG          // камера чуть сверху
        val ce = cos(e); val se = sin(e)
        val dist = if (view == VIEW_REAR) 260f else 320f              // лёгкая перспектива
        val zc = 10f                                                  // центр по высоте
        // свет: сверху-слева-спереди (в осях камеры: вправо, вверх, вглубь)
        var lx = -0.35f; var ly = 0.75f; var lz = -0.55f
        val ln = sqrt(lx * lx + ly * ly + lz * lz); lx /= ln; ly /= ln; lz /= ln

        // машина → мир (сначала крен вокруг X, потом тангаж вокруг Y) → камера (вправо, вверх, глубина)
        fun cam(p: FloatArray, out: FloatArray, isVec: Boolean) {
            val x = p[0]; val y = p[1]; val z = if (isVec) p[2] else p[2] - zc
            val y1 = y * cr - z * sr; val z1 = y * sr + z * cr                  // крен: правый борт (y<0) вниз
            val x2 = x * cp - z1 * sp; val z2 = x * sp + z1 * cp                // тангаж: нос (x>0) вверх
            if (view == VIEW_REAR) {
                out[0] = -y1; out[1] = z2 * ce + x2 * se; out[2] = x2 * ce - z2 * se
            } else {
                out[0] = x2; out[1] = z2 * ce + y1 * se; out[2] = y1 * ce - z2 * se
            }
        }

        buf.clear()
        val a = FloatArray(3); val b = FloatArray(3); val nrm = FloatArray(3)
        for (f in faces) {
            val p = f.p
            // нормаль грани наружу (в осях машины)
            val u0 = p[1][0] - p[0][0]; val u1 = p[1][1] - p[0][1]; val u2 = p[1][2] - p[0][2]
            val w0 = p[2][0] - p[0][0]; val w1 = p[2][1] - p[0][1]; val w2 = p[2][2] - p[0][2]
            var n0 = u1 * w2 - u2 * w1; var n1 = u2 * w0 - u0 * w2; var n2 = u0 * w1 - u1 * w0
            var gx = 0f; var gy = 0f; var gz = 0f
            for (q in p) { gx += q[0]; gy += q[1]; gz += q[2] }
            gx /= p.size; gy /= p.size; gz /= p.size
            if (n0 * (gx - f.inside[0]) + n1 * (gy - f.inside[1]) + n2 * (gz - f.inside[2]) < 0) { n0 = -n0; n1 = -n1; n2 = -n2 }
            nrm[0] = n0; nrm[1] = n1; nrm[2] = n2
            cam(nrm, a, true)
            if (a[2] >= -1e-4f) continue                                // смотрит от камеры
            val l = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
            val lit = 0.55f + 0.6f * max(0f, (a[0] * lx + a[1] * ly + a[2] * lz) / l)
            val xy = FloatArray(p.size * 2)
            var depth = 0f
            for (i in p.indices) {
                cam(p[i], b, false)
                val pr = dist / (dist + b[2])
                xy[2 * i] = cx + k * b[0] * pr
                xy[2 * i + 1] = cy - k * b[1] * pr
                depth += b[2]
            }
            buf.add(Drawn(depth / p.size, shade(f.color, lit), xy))
        }
        buf.sortByDescending { it.depth }                               // дальние — первыми
        for (d in buf) g.polyA(d.color, 255, *d.xy)
    }
}
