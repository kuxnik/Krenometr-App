package ru.diy.krenometr

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/** Круглый прибор: рисует текущую страницу, свайп — листать, касание — сброс максимумов, удержание — ноль/поездка. */
@SuppressLint("ViewConstructor")
class DialView(ctx: Context, private val dial: Dial, private val link: KrenLink) : View(ctx) {
    var page = Pages.TILT
    var onPageSwipe: ((Int) -> Unit)? = null
    var onTap: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onLongPress(e: MotionEvent) { onLong?.invoke() }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (e1 == null) return false
            val dx = e2.x - e1.x; val dy = e2.y - e1.y
            if (abs(dx) > 80 && abs(dx) > abs(dy)) { onPageSwipe?.invoke(if (dx < 0) 1 else -1); return true }
            return false
        }
    })

    init { setBackgroundColor(Color.BLACK) }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean = gd.onTouchEvent(event) || super.onTouchEvent(event)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // квадрат по высоте (горизонтальный экран магнитолы)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val s = if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.UNSPECIFIED) h else min(w, h)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val size = min(width, height).toFloat() - 8f
        dial.draw(canvas, page, (width - size) / 2f, (height - size) / 2f, size, link.connected)
    }
}

/** Правая панель: крупные цифры по машине и состояние кренометра. */
class PanelView(ctx: Context, private val m: Model, private val link: KrenLink) : View(ctx) {
    private val card = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.CARD }
    private val lbl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.GRAY; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val vp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.GRAY; typeface = Typeface.DEFAULT }
    private val r = RectF()

    init { setBackgroundColor(Color.BLACK) }

    private class Tile(val label: String, val value: String, val unit: String, val color: Int)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val pad = h * 0.02f
        val car = m.have && m.can
        val tiles = arrayOf(
            Tile("Скорость", if (car && m.speed >= 0) "${m.speed}" else "—", "км/ч", C.WHITE),
            Tile("Обороты", if (car && m.rpm >= 0) "${m.rpm}" else "—", "об/мин",
                if (m.rpm >= Dial.RPM_DANGER) C.RED else if (m.rpm >= Dial.RPM_WARN) C.YELLOW else C.WHITE),
            Tile("Наддув", if (car && m.boostOk) fmtNum(m.boost, 2) else "—", "бар",
                if (m.boost >= Dial.BOOST_DANGER) C.RED else if (m.boost >= Dial.BOOST_WARN) C.YELLOW else C.WHITE),
            Tile("ОЖ", if (car && m.cool > -100) "${m.cool}" else "—", "°C",
                if (m.cool >= Dial.COOL_DANGER) C.RED else if (m.cool >= Dial.COOL_WARN) C.YELLOW
                else if (m.cool > -100 && m.cool < Dial.COOL_COLD) C.TEAL else C.WHITE),
            Tile("ATF", if (m.have && m.atf > -100) "${m.atf}" else "—", "°C",
                if (m.atf >= 110) C.RED else if (m.atf >= 100) C.YELLOW else C.WHITE),
            Tile("Бортсеть", if (car && m.volt > 0) fmtNum(m.volt, 1) else "—", "В",
                if (m.volt > 0 && (m.volt < 12.0f || m.volt > 14.8f)) C.ORANGE else C.WHITE),
            Tile("Крен", if (m.have) fmtNum(m.roll.roundToInt().toFloat(), 0, "°") else "—", "макс ${m.maxRoll.roundToInt()}°",
                zoneWhite(m.roll, Dial.ROLL_WARN, Dial.ROLL_DANGER)),
            Tile("Дифферент", if (m.have) fmtNum(m.pitch.roundToInt().toFloat(), 0, "°") else "—", "макс ${m.maxPitch.roundToInt()}°",
                zoneWhite(m.pitch, Dial.PITCH_WARN, Dial.PITCH_DANGER))
        )
        val cols = 2; val rows = 4
        val statusH = h * 0.2f
        val tw = (w - pad * (cols + 1)) / cols
        val th = (h - statusH - pad * (rows + 1)) / rows
        for (i in tiles.indices) {
            val cx = pad + (i % cols) * (tw + pad)
            val cy = pad + (i / cols) * (th + pad)
            r.set(cx, cy, cx + tw, cy + th)
            canvas.drawRoundRect(r, th * 0.15f, th * 0.15f, card)
            val t = tiles[i]
            lbl.textSize = th * 0.2f
            canvas.drawText(t.label, cx + th * 0.15f, cy + th * 0.3f, lbl)
            vp.textSize = th * 0.5f
            vp.color = t.color
            val vw = vp.measureText(t.value)
            canvas.drawText(t.value, cx + th * 0.15f, cy + th * 0.85f, vp)
            lbl.textSize = th * 0.18f
            canvas.drawText(t.unit, cx + th * 0.15f + vw + th * 0.1f, cy + th * 0.85f, lbl)
        }
        // строка состояния
        sp.textSize = statusH * 0.2f
        var y = h - statusH + statusH * 0.3f
        for ((text, color) in statusLines()) {
            sp.color = color
            canvas.drawText(text, pad, y, sp)
            y += statusH * 0.27f
        }
    }

    private fun zoneWhite(v: Float, warn: Float, danger: Float): Int {
        val z = zone(v, warn, danger)
        return if (z == C.GREEN) C.WHITE else z
    }

    private fun statusLines(): List<Pair<String, Int>> {
        if (!link.connected) return listOf(
            "Нет связи с кренометром" to C.ORANGE,
            if (link.network == null) "Wi-Fi «${KrenLink.SSID}» не подключён" to C.GRAY
            else "Wi-Fi есть, кренометр не отвечает" to C.GRAY
        )
        val elm = when (m.elm) {
            0 -> "ELM327: ищу сеть адаптера" to C.ORANGE
            1 -> "ELM327: сеть есть, адаптер не отвечает" to C.ORANGE
            2 -> "ELM327: подключён, ЭБУ молчит (зажигание?)" to C.YELLOW
            3 -> (if (m.termPause) "ELM327: опрос на паузе (терминал)" else "ELM327: данные идут") to
                    (if (m.termPause) C.YELLOW else C.GREEN)
            else -> "ELM327: —" to C.GRAY
        }
        val compass = (if (m.hs == 2) (if (m.ma >= 2) "компас магнитный" else "компас: калибровка (восьмёрка)")
            else if (m.bn == 0) "компас по гироскопу, BNO085 не найден" else "компас по гироскопу") +
            (if (m.ts == 2) " · крен по BNO085" else " · крен по датчику платы")
        val fw = if (m.legacy) "Прошивка 3.9 — обновите до 3.10 (колёса, G, трек, 25 Гц)" to C.ORANGE
            else ("Связь 25 Гц · экран кренометра " + (if (m.screenOn) "вкл" else "выкл")) to C.GRAY2
        return listOf(elm, compass to C.GRAY, fw)
    }
}
