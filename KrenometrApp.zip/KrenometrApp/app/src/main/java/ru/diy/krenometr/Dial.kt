package ru.diy.krenometr

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Круглые экраны кренометра — перенос рисования из прошивки 3.10 один к одному:
 * те же координаты (круг 240×240), цвета и пороги.
 */
class Dial(private val m: Model, private val link: KrenLink) {
    companion object {
        const val ROLL_WARN = 15f
        const val ROLL_DANGER = 25f
        const val PITCH_WARN = 15f
        const val PITCH_DANGER = 25f
        const val BOOST_MAX = 2.0f
        const val BOOST_WARN = 1.3f
        const val BOOST_DANGER = 1.5f
        const val COOL_COLD = 60f
        const val COOL_WARN = 100f
        const val COOL_DANGER = 106f
        const val RPM_MAX = 4500f
        const val RPM_WARN = 3800f
        const val RPM_DANGER = 4100f
        const val TL_K = 1.25f
        const val AH_PX_PER_DEG = 2.8f
        const val GM_SCALE = 96f
        val WD_SHORT = arrayOf("ВС", "ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ")
    }

    private val g = Gfx()
    private val clip = Path()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bgShader: RadialGradient? = null

    var toastText = ""
    var toastAt = 0L

    fun toast(s: String) { toastText = s; toastAt = android.os.SystemClock.elapsedRealtime() }

    /** Нарисовать страницу в квадрат size×size с левым верхним углом (ox, oy). */
    fun draw(canvas: Canvas, page: Int, ox: Float, oy: Float, size: Float, connected: Boolean) {
        g.c = canvas
        canvas.save()
        canvas.translate(ox, oy)
        canvas.scale(size / 240f, size / 240f)
        clip.reset()
        clip.addCircle(120f, 120f, 120f, Path.Direction.CW)
        canvas.clipPath(clip)

        when {
            !m.have -> noLink()
            !m.imu -> {
                g.text(120f, 112f, "Датчик не найден", F.MED, C.RED)
                g.text(120f, 136f, "QMI8658 не отвечает", F.SMALL, C.GRAY)
            }
            m.cal -> {
                val a = (android.os.SystemClock.elapsedRealtime() % 100000L) / 300f
                g.arc(120f, 120f, 60f, 6f, a, a + 1.6f, C.BLUE)
                g.text(120f, 116f, "Не двигайте", F.MED, C.WHITE)
                g.text(120f, 138f, "калибровка", F.SMALL, C.GRAY)
            }
            else -> when (page) {
                Pages.TILT -> pageTilt()
                Pages.WHEELS -> pageWheels()
                Pages.HORIZON -> pageHorizon()
                Pages.NAV -> pageNav()
                Pages.TRACK -> pagePath()
                Pages.CLOCK -> pageClock()
                Pages.GMETER -> pageGMeter()
            }
        }
        if (m.have && !connected) {
            g.rrect(120f, 120f, 70f, 15f, 15f, 0f, C.BG, 200)
            g.text(120f, 125f, "связь потеряна", F.SMALL, C.ORANGE)
        }
        drawToast()
        canvas.restore()
    }

    private fun noLink() {
        val a = (android.os.SystemClock.elapsedRealtime() % 100000L) / 500f
        g.arc(120f, 120f, 100f, 3f, a, a + 0.8f, C.GRAY4)
        g.text(120f, 108f, "Нет связи", F.MED, C.WHITE)
        g.text(120f, 130f, "с кренометром", F.SMALL, C.GRAY)
        g.text(120f, 156f, "Wi-Fi: " + KrenLink.SSID, F.TINY, C.BLUE)
        g.text(120f, 172f, "192.168.4.1", F.TINY, C.GRAY2)
    }

    private fun drawToast() {
        if (toastText.isEmpty()) return
        val age = android.os.SystemClock.elapsedRealtime() - toastAt
        if (age > 1600) return
        val al = if (age > 1300) (255 - (age - 1300) * 255 / 300).toInt() else 255
        val w = g.textWidth(toastText, F.SMALL) + 28f
        g.rrect(120f, 120f, w / 2f, 17f, 17f, 0f, C.CARD, al)
        g.text(120f, 125f, toastText, F.SMALL, C.WHITE, AL_CENTER, al)
    }

    // ===================== силуэты Pajero Sport =====================
    private fun carBegin(cx: Float, cy: Float, angDeg: Float, scale: Float) {
        g.c.save()
        g.c.translate(cx, cy)
        g.c.rotate(angDeg)
        g.c.scale(scale, scale)
    }

    /** Вид сзади: положительный крен — правый борт ниже (по часовой). */
    private fun carRear(cx: Float, cy: Float, rollDeg: Float, scale: Float) {
        carBegin(cx, cy, rollDeg, scale)
        g.rrect(-25f, 16f, 7.5f, 9f, 3f, 0f, C.CAR_TIRE)
        g.rrect(25f, 16f, 7.5f, 9f, 3f, 0f, C.CAR_TIRE)
        g.rrect(0f, 17f, 12f, 2.5f, 1.5f, 0f, C.CAR_TIRE)
        g.rrect(-35f, 8f, 3f, 6.5f, 2f, 0f, C.CAR_TRIM)
        g.rrect(35f, 8f, 3f, 6.5f, 2f, 0f, C.CAR_TRIM)
        g.rrect(-38f, -13f, 3.5f, 2.5f, 1.5f, 0f, C.CAR_BLUE)
        g.rrect(38f, -13f, 3.5f, 2.5f, 1.5f, 0f, C.CAR_BLUE)
        g.poly(C.CAR_BLUE, -31f, -4f, 31f, -4f, 27f, -24f, 23f, -28f, -23f, -28f, -27f, -24f)
        g.poly(C.CAR_BLUE, -35f, -6f, 35f, -6f, 36f, 9f, 34f, 14f, -34f, 14f, -36f, 9f)
        g.line(-22f, -31f, -22f, -28f, 2f, C.CAR_TRIM)
        g.line(22f, -31f, 22f, -28f, 2f, C.CAR_TRIM)
        g.rrect(0f, -34f, 25f, 3.8f, 3.5f, 0f, C.CAR_BOX)
        g.line(-21f, -36.5f, 21f, -36.5f, 1f, C.CAR_BOX_HL)
        g.poly(C.CAR_GLASS, -24f, -12f, 24f, -12f, 21f, -24f, -21f, -24f)
        g.line(0f, -13f, -9f, -16f, 1f, C.CAR_TRIM)
        g.poly(C.CAR_TAIL, -36f, -6f, -21f, -6f, -22f, -1f, -36f, 1f)
        g.poly(C.CAR_TAIL, 21f, -6f, 36f, -6f, 36f, 1f, 22f, -1f)
        g.rrect(-31f, -1.5f, 3f, 1.2f, 0.6f, 0f, C.CAR_AMBER)
        g.rrect(31f, -1.5f, 3f, 1.2f, 0.6f, 0f, C.CAR_AMBER)
        g.rrect(0f, 4f, 9f, 3.5f, 1f, 0f, C.PLATE)
        g.rrect(0f, 12f, 34f, 3f, 1.5f, 0f, C.CAR_TRIM)
        g.rrect(-26f, 11.5f, 3f, 1.2f, 0.6f, 0f, C.CAR_TAIL)
        g.rrect(26f, 11.5f, 3f, 1.2f, 0.6f, 0f, C.CAR_TAIL)
        g.c.restore()
    }

    /** Вид сбоку, мордой вправо: нос вверх — против часовой. */
    private fun carSide(cx: Float, cy: Float, pitchDeg: Float, scale: Float) {
        carBegin(cx, cy, -pitchDeg, scale)
        g.line(-30f, -31f, -30f, -28f, 2f, C.CAR_TRIM)
        g.line(4f, -31f, 4f, -28f, 2f, C.CAR_TRIM)
        g.poly(C.CAR_BOX, -38f, -31f, -36f, -37f, -20f, -39.5f, 8f, -38.5f, 15f, -33f, 13f, -31f)
        g.line(-33f, -37.5f, 6f, -38f, 1f, C.CAR_BOX_HL)
        g.line(-41f, -29.5f, 12f, -29.5f, 1.8f, C.CAR_TRIM)
        g.poly(C.CAR_BLUE, -49f, -7f, -45f, -24f, -39f, -28f, 14f, -28f, 33f, -9f)
        g.poly(C.CAR_BLUE, -50f, -7f, 38f, -9f, 48f, -3f, 50f, 6f, -50f, 7f)
        g.poly(C.CAR_GLASS, -45f, -11f, -42f, -24f, -37f, -25.5f, 12f, -25.5f, 28f, -11f)
        g.line(-23f, -25f, -23f, -11f, 2.2f, C.CAR_TRIM)
        g.line(-1.5f, -25f, -1.5f, -11f, 2.2f, C.CAR_TRIM)
        g.line(-22f, -26.5f, 12f, -26.5f, 1f, C.CAR_TRIM)
        g.poly(C.CAR_BLUE, 26f, -12f, 31f, -12f, 31f, -7f, 27f, -7f)
        g.line(-17f, -6f, -13f, -6f, 1.3f, C.CAR_CHROME)
        g.line(5f, -6f, 9f, -6f, 1.3f, C.CAR_CHROME)
        g.line(-24f, 2f, 31f, 1.5f, 1f, C.CAR_DARK)
        g.line(-1f, -9f, -1f, 6f, 0.8f, C.CAR_DARK)
        g.poly(C.HEADLIGHT, 44f, -6f, 49f, -2f, 49f, 0f, 45f, -1f)
        g.poly(C.CAR_TAIL, -50f, -7f, -44f, -8f, -44f, -2f, -50f, -1f)
        for (wx in floatArrayOf(-29f, 30f)) {
            g.circle(wx, 11f, 12.5f, C.BG)
            g.arc(wx, 11f, 12.8f, 3f, 188f * DEG, 352f * DEG, C.CAR_TRIM)
            g.rrect(wx - 12.5f, 14f, 1.4f, 5f, 0.7f, 0f, C.CAR_TRIM)
            g.circle(wx, 11f, 10.5f, C.CAR_TIRE)
            g.circle(wx, 11f, 6.8f, C.CAR_RIM)
            g.circle(wx, 11f, 4.4f, C.CAR_RIM2)
            g.circle(wx, 11f, 1.8f, C.CAR_TRIM)
        }
        g.c.restore()
    }

    // ===================== кренометр =====================
    private fun tlAng(side: Int, v: Float): Float =
        if (side < 0) (180f - v * TL_K) * DEG else (-v * TL_K) * DEG

    private fun tiltScale(side: Int) {
        val rt = 90f
        var v = -44
        while (v <= 44) {
            if (v != 0) {
                val av = abs(v)
                if (av <= 40) {
                    val a = tlAng(side, v.toFloat()); val ca = cos(a); val sa = sin(a)
                    val major = av % 10 == 0
                    val c = if (av >= 30) C.TL_HOT else C.WHITE
                    val r0 = if (major) rt - 9 else if (av % 10 == 5) rt - 6 else rt - 4
                    g.line(120 + r0 * ca, 120 + r0 * sa, 120 + rt * ca, 120 + rt * sa, if (major) 1.6f else 1.0f, c)
                    if (major) g.text(120 + (rt + 12) * ca, 120 + (rt + 12) * sa + 4.5f, "$av", F.SMALL, c)
                }
            }
            v += 2
        }
        for (sgn in intArrayOf(-1, 1)) {
            val a0 = tlAng(side, sgn * 30f); val a1 = tlAng(side, sgn * 40f)
            g.arc(120f, 120f, rt, 1.4f, min(a0, a1), max(a0, a1), C.TL_HOT)
            val ca = cos(a1); val sa = sin(a1)
            g.line(120 + (rt - 10) * ca, 120 + (rt - 10) * sa, 120 + rt * ca, 120 + rt * sa, 1.6f, C.TL_HOT)
        }
    }

    private fun tiltPointer(side: Int, v: Float, color: Int) {
        val a = tlAng(side, v.coerceIn(-45f, 45f)); val ca = cos(a); val sa = sin(a)
        val tip = 77f; val base = 66f; val hw = 6f
        g.poly(color,
            120 + tip * ca, 120 + tip * sa,
            120 + base * ca - hw * sa, 120 + base * sa + hw * ca,
            120 + base * ca + hw * sa, 120 + base * sa - hw * ca)
    }

    private fun pageTilt() {
        val roll = m.roll; val pitch = m.pitch
        tiltScale(-1)
        tiltScale(1)
        g.line(36f, 120f, 204f, 120f, 1.3f, C.TL_RED)
        g.poly(C.TL_BLUE, 37f, 120f, 31f, 116.5f, 31f, 123.5f)
        g.poly(C.TL_BLUE, 203f, 120f, 209f, 116.5f, 209f, 123.5f)
        g.line(15f, 120f, 23f, 120f, 2.2f, C.WHITE)
        g.line(217f, 120f, 225f, 120f, 2.2f, C.WHITE)
        g.line(221f, 116f, 221f, 124f, 2.2f, C.WHITE)

        val rc = zone(roll, ROLL_WARN, ROLL_DANGER); val pc = zone(pitch, PITCH_WARN, PITCH_DANGER)
        tiltPointer(-1, roll, if (rc == C.RED) C.RED else C.TL_AMBER)
        tiltPointer(1, pitch, if (pc == C.RED) C.RED else C.TL_AMBER)

        carRear(120f, 72f, roll, 0.68f)
        carSide(120f, 152f, pitch, 0.66f)
        g.text(120f, 110f, fmtNum(roll.roundToInt().toFloat(), 0), F.VAL, if (rc == C.GREEN) C.WHITE else rc)
        g.text(120f, 203f, fmtNum(pitch.roundToInt().toFloat(), 0), F.VAL, if (pc == C.GREEN) C.WHITE else pc)
    }

    // ===================== компас =====================
    private fun dirName(h: Float): String {
        val n = arrayOf("С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ")
        return n[((Model.wrap360(h) + 22.5f) / 45f).toInt() % 8]
    }

    private fun pageCompass() {
        val hdg = m.hdg
        var b = 0
        while (b < 360) {
            val a = (b - hdg - 90) * DEG; val cs = cos(a); val sn = sin(a)
            val major = b % 30 == 0
            val r1 = if (major) 94f else 100f; val r2 = 108f
            g.line(120 + r1 * cs, 120 + r1 * sn, 120 + r2 * cs, 120 + r2 * sn, if (major) 2.2f else 1.2f, if (major) C.WHITE else C.GRAY2)
            b += 3
        }
        run {
            val a = (-hdg - 90) * DEG; val cs = cos(a); val sn = sin(a)
            g.poly(C.RED, 120 + 119 * cs, 120 + 119 * sn,
                120 + 111 * cs - 5 * sn, 120 + 111 * sn + 5 * cs,
                120 + 111 * cs + 5 * sn, 120 + 111 * sn - 5 * cs)
        }
        val card = arrayOf("С", "В", "Ю", "З")
        b = 0
        while (b < 360) {
            val a = (b - hdg - 90) * DEG; val cs = cos(a); val sn = sin(a)
            if (b % 90 == 0) g.text(120 + 70 * cs, 120 + 70 * sn + 7, card[b / 90], F.MED, if (b == 0) C.RED else C.WHITE)
            else g.text(120 + 82 * cs, 120 + 82 * sn + 4, "$b", F.TINY, C.GRAY)
            b += 30
        }
        g.line(120f, 2f, 120f, 24f, 3f, C.WHITE)
        g.text(124f, 132f, "${Model.wrap360(hdg).roundToInt() % 360}°", F.BIG, C.WHITE)
        g.text(120f, 156f, dirName(hdg), F.SMALL, C.GRAY)
        val s = if (m.hs == 2) (if (m.ma >= 2) "магнитный" else "калибровка")
            else if (m.hs == 3) "гироскоп · выставлен по GPS"
            else if (m.bn == 0) (if (m.gpsFresh) "по гироскопу · выставится по GPS в движении" else "по гироскопу · BNO085 не найден")
            else if (m.bn >= 1) "по гироскопу · BNO085 молчит" else "по гироскопу"
        g.text(120f, 174f, s, F.TINY, if (m.hs == 2 && m.ma < 2) C.ORANGE else C.GRAY2)
    }

    // ===================== одометр + компас =====================
    private val drumPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Ряд барабанов как в механическом одометре; последние dec — доли (красные). */
    private fun drumRow(cx: Float, cy: Float, n: Int, dec: Int, value: Double, cw: Float, ch: Float, size: Float, capH: Float) {
        val gap = 2f
        var scale = 1.0; repeat(dec) { scale *= 10 }
        var lim = 1.0; repeat(n) { lim *= 10 }
        var u = value * scale
        if (u < 0) u = 0.0
        u %= lim
        val iu = u.toLong()
        val fr = (u - iu).toFloat()
        val w = n * cw + (n - 1) * gap
        g.rrect(cx, cy, w / 2 + 3, ch / 2 + 3, 4f, 0f, Color.rgb(70, 70, 74))
        g.rrect(cx, cy, w / 2 + 1.8f, ch / 2 + 1.8f, 3f, 0f, Color.rgb(8, 8, 9))
        var p = 1L
        for (k in 0 until n) {
            val x = cx + w / 2 - cw / 2 - k * (cw + gap)
            val digit = ((iu / p) % 10).toInt()
            val roll = if (k == 0) fr else if (iu % p == p - 1) fr else 0f
            val frac = k < dec
            val bg = if (frac) Color.rgb(150, 28, 24) else Color.rgb(30, 30, 33)
            val fg = if (frac) Color.rgb(255, 236, 230) else Color.rgb(236, 236, 236)
            g.rrect(x, cy, cw / 2, ch / 2, 1.5f, 0f, bg)
            g.c.save()
            g.c.clipRect(x - cw / 2, cy - ch / 2, x + cw / 2, cy + ch / 2)
            val base = cy + capH / 2 - roll * ch
            g.text(x, base, "$digit", size, fg)
            if (roll > 0.001f) g.text(x, base + ch, "${(digit + 1) % 10}", size, fg)
            g.c.restore()
            g.rrect(x, cy - ch / 2 + ch * 0.12f, cw / 2, ch * 0.12f, 0f, 0f, C.BG, 110)
            g.rrect(x, cy + ch / 2 - ch * 0.12f, cw / 2, ch * 0.12f, 0f, 0f, C.BG, 110)
            p *= 10
        }
    }

    private fun pageNav() {
        val hdg = m.hdg
        var b = 0
        while (b < 360) {
            val a = (b - hdg - 90) * DEG; val cs = cos(a); val sn = sin(a)
            val major = b % 30 == 0
            val r1 = if (major) 104f else 108f; val r2 = 115f
            g.line(120 + r1 * cs, 120 + r1 * sn, 120 + r2 * cs, 120 + r2 * sn, if (major) 2.0f else 1.0f, if (major) C.WHITE else C.GRAY2)
            b += 5
        }
        run {
            val a = (-hdg - 90) * DEG; val cs = cos(a); val sn = sin(a)
            g.poly(C.RED, 120 + 119 * cs, 120 + 119 * sn,
                120 + 112 * cs - 4.5f * sn, 120 + 112 * sn + 4.5f * cs,
                120 + 112 * cs + 4.5f * sn, 120 + 112 * sn - 4.5f * cs)
        }
        val card = arrayOf("С", "В", "Ю", "З")
        b = 0
        while (b < 360) {
            val a = (b - hdg - 90) * DEG
            g.text(120 + 93 * cos(a), 120 + 93 * sin(a) + 5.5f, card[b / 90], F.SMALL, if (b == 0) C.RED else C.WHITE)
            b += 90
        }
        g.poly(C.WHITE, 120f, 16f, 115f, 6f, 125f, 6f)
        g.text(120f, 60f, "${Model.wrap360(hdg).roundToInt() % 360}° ${dirName(hdg)}", F.MED, C.WHITE)

        g.text(120f, 83f, "пробег, км", F.TINY, C.GRAY)
        drumRow(120f, 102f, 7, 1, if (m.totalKm >= 0) m.totalKm else 0.0, 17f, 25f, F.MED, 15.5f)
        g.text(120f, 134f, "поездка, км", F.TINY, C.GRAY)
        drumRow(120f, 150f, 5, 1, m.odo / 1000.0, 14f, 20f, F.SMALL, 11f)
        g.text(120f, 182f, if (m.engineH >= 0) "моточасы " + fmtNum(m.engineH.toFloat(), 1) else "моточасы — с прошивки 3.13",
            F.SMALL, Color.rgb(200, 200, 204))
        val spd = m.can || m.gpsFresh
        val st = if (!spd) "нет скорости: ELM327 или GPS"
            else if (m.hs == 2) (if (m.ma >= 2) "компас магнитный" else "компас: калибровка")
            else if (m.hs == 3) "курс по GPS" else "курс по гироскопу"
        g.text(120f, 200f, st, F.TINY, if (!spd) C.ORANGE else C.GRAY2)
    }

    // ===================== колёса =====================
    private fun wheelsBackground() {
        if (bgShader == null) {
            // к центру светлее (тёмно-синий), к краю почти чёрный
            val stops = FloatArray(9) { it / 8f }
            val cols = IntArray(9) {
                val k = Math.pow(stops[it] * stops[it].toDouble(), 0.8).toFloat()
                Color.rgb((30 + (6 - 30) * k).toInt(), (40 + (8 - 40) * k).toInt(), (54 + (12 - 54) * k).toInt())
            }
            bgShader = RadialGradient(120f, 120f, 120f, cols, stops, Shader.TileMode.CLAMP)
        }
        bgPaint.shader = bgShader
        g.c.drawCircle(120f, 120f, 120f, bgPaint)
    }

    private fun pageWheels() {
        wheelsBackground()
        val rr = 111.6f
        g.ring(120f, 120f, rr, 7f, Color.rgb(20, 70, 120), 90)
        g.ring(120f, 120f, rr, 3.5f, Color.rgb(30, 100, 160), 140)
        g.ring(120f, 120f, rr, 1.2f, Color.rgb(52, 128, 190))
        var d = 0
        while (d < 360) {
            val a = (d - 90) * DEG; val ca = cos(a); val sa = sin(a)
            if (d % 90 == 0) g.line(120 + (rr - 5) * ca, 120 + (rr - 5) * sa, 120 + (rr + 0.5f) * ca, 120 + (rr + 0.5f) * sa, 1.6f, Color.rgb(140, 200, 240))
            else g.line(120 + (rr - 2.6f) * ca, 120 + (rr - 2.6f) * sa, 120 + rr * ca, 120 + rr * sa, 0.8f, Color.rgb(70, 120, 160))
            d += 30
        }
        val kb = 74.4f / ROLL_DANGER
        g.ring(120f, 120f, ROLL_WARN * kb, 0.7f, Color.rgb(120, 100, 30))
        g.ring(120f, 120f, ROLL_DANGER * kb, 0.7f, Color.rgb(130, 40, 36))

        val cx = 120f; val cy = 120f
        val out = Color.rgb(90, 110, 135); val out2 = Color.rgb(70, 88, 110)
        g.rrOutline(cx, cy, 23f, 46f, 14f, 1.1f, out)
        g.rrOutline(cx, cy - 22, 17f, 6f, 3f, 0.8f, out2)
        g.rrOutline(cx, cy + 34, 16f, 4f, 2.5f, 0.8f, out2)

        // порядок данных ABS: ПП, ПЛ, ЗП, ЗЛ
        val wx = floatArrayOf(27f, -27f, 27f, -27f); val wy = floatArrayOf(-30f, -30f, 30f, 30f)
        val moving = m.wheelsMoving
        for (i in 0 until 4) {
            val dv = m.wheelDev[i]
            val c = if (!moving) Color.rgb(58, 66, 78)
                else if (dv > 0.08f) C.RED else if (dv > 0.04f) C.ORANGE else if (dv < -0.04f) C.BLUE else C.GREEN
            val x = cx + wx[i]; val y = cy + wy[i]
            if (moving && dv > 0.04f) {
                g.rrect(x, y, 10f, 17f, 9f, 0f, c, 45)
                g.rrect(x, y, 7.5f, 14.5f, 7f, 0f, c, 70)
            }
            g.rrect(x, y, 5f, 12f, 4f, 0f, c)
            val bx = cx + if (wx[i] > 0) 45f else -45f
            g.line(bx, y - 26, bx, y + 26, 4f, Color.rgb(40, 52, 66))
            if (moving) {
                val l = (dv / 0.15f).coerceIn(-1f, 1f) * 26f
                if (abs(l) > 1f) { g.line(bx, y, bx, y - l, 9f, c, 50); g.line(bx, y, bx, y - l, 4f, c) }
            }
        }

        val ret = Color.rgb(200, 210, 220)
        g.ring(120f, 120f, 14f, 0.9f, ret)
        d = 0
        while (d < 360) {
            val a = d * DEG; val ca = cos(a); val sa = sin(a)
            g.line(120 + 11 * ca, 120 + 11 * sa, 120 + 19 * ca, 120 + 19 * sa, 0.9f, ret)
            d += 90
        }
        val roll = m.roll; val pitch = m.pitch
        val bx = 120 + (roll / ROLL_DANGER).coerceIn(-1.1f, 1.1f) * 74.4f
        val by = 120 + (pitch / PITCH_DANGER).coerceIn(-1.1f, 1.1f) * 74.4f
        val lvl = max(abs(roll) / ROLL_DANGER, abs(pitch) / PITCH_DANGER)
        val lvlW = max(abs(roll) / ROLL_WARN, abs(pitch) / PITCH_WARN)
        val bc = if (lvl >= 1) C.RED else if (lvlW >= 1) C.YELLOW else C.GREEN
        g.circle(bx, by, 17f, bc, 28)
        g.circle(bx, by, 13f, bc, 50)
        g.circle(bx, by, 9f, bc)
        val hl = Color.rgb(min(255, Color.red(bc) + 90), min(255, Color.green(bc) + 90), min(255, Color.blue(bc) + 90))
        g.circle(bx - 2.6f, by - 3.2f, 2.6f, hl)

        if (!m.wheelsFresh) g.text(120f, 214f, if (m.legacy) "колёса — с прошивки 3.10" else "нет данных ABS", F.TINY, Color.rgb(90, 104, 120))
    }

    // ===================== авиагоризонт =====================
    private fun ahTriangle(ang: Float, rTip: Float, rBase: Float, halfW: Float, color: Int) {
        val ca = cos(ang); val sa = sin(ang)
        g.poly(color,
            120 + rTip * ca, 120 + rTip * sa,
            120 + rBase * ca - halfW * sa, 120 + rBase * sa + halfW * ca,
            120 + rBase * ca + halfW * sa, 120 + rBase * sa - halfW * ca)
    }

    private fun pageHorizon() {
        val roll = m.roll; val pitch = m.pitch
        val a = roll * DEG
        val nx = sin(a); val ny = cos(a)
        val tx = ny; val ty = -nx
        val k = AH_PX_PER_DEG
        val hcx = 120 + nx * pitch * k; val hcy = 120 + ny * pitch * k

        g.c.drawColor(C.AH_SKY)
        g.halfPlane(hcx, hcy, nx, ny, C.AH_GND)
        g.line(hcx - tx * 130, hcy - ty * 130, hcx + tx * 130, hcy + ty * 130, 1.6f, C.WHITE)

        val lo = floor((pitch - 22) / 5).toInt() * 5; val hi = ceil((pitch + 22) / 5).toInt() * 5
        var th = lo
        while (th <= hi) {
            if (th != 0 && abs(th) <= 60) {
                val lx = hcx - nx * th * k; val ly = hcy - ny * th * k
                val ddx = lx - 120; val ddy = ly - 120
                if (ddx * ddx + ddy * ddy <= 46 * 46) {
                    val major = th % 10 == 0
                    val hw = if (major) 26f else 12f
                    if (th > 0 || !major) {
                        g.line(lx - tx * hw, ly - ty * hw, lx + tx * hw, ly + ty * hw, 1.4f, C.WHITE)
                    } else {
                        for (s in floatArrayOf(-1f, 1f)) {
                            g.line(lx + s * tx * hw, ly + s * ty * hw, lx + s * tx * 16, ly + s * ty * 16, 1.4f, C.WHITE)
                            g.line(lx + s * tx * 11, ly + s * ty * 11, lx + s * tx * 4, ly + s * ty * 4, 1.4f, C.WHITE)
                        }
                    }
                    if (major) for (s in floatArrayOf(-1f, 1f))
                        g.text(lx + s * tx * (hw + 10), ly + s * ty * (hw + 10) + 4, "${abs(th)}", F.TINY, C.WHITE)
                }
            }
            th += 5
        }

        val rs = 98f
        g.arc(120f, 120f, rs, 1.5f, (-90 - 60) * DEG, (-90 + 60) * DEG, C.WHITE)
        for (t in intArrayOf(10, 20, 30, 45, 60)) for (s in intArrayOf(-1, 1)) {
            val an = (-90 + s * t) * DEG
            val r2 = if (t == 30 || t == 60) rs + 10 else rs + 6
            g.line(120 + rs * cos(an), 120 + rs * sin(an), 120 + r2 * cos(an), 120 + r2 * sin(an), 1.6f, C.WHITE)
        }
        for (z in floatArrayOf(ROLL_WARN, ROLL_DANGER)) for (s in intArrayOf(-1, 1)) {
            val an = (-90 + s * z) * DEG
            g.circle(120 + rs * cos(an), 120 + rs * sin(an), 2.6f, if (z == ROLL_WARN) C.YELLOW else C.RED)
        }
        ahTriangle(-90 * DEG, rs + 1, rs + 11, 6f, C.WHITE)
        val rc = zone(roll, ROLL_WARN, ROLL_DANGER)
        ahTriangle((-90 - roll) * DEG, rs - 1, rs - 12, 6.5f, if (rc == C.GREEN) C.WHITE else rc)

        val ac = C.YELLOW; val ol = Color.rgb(20, 20, 20)
        for (pass in 0..1) {
            val w = if (pass == 1) 4.0f else 6.5f; val c = if (pass == 1) ac else ol
            g.line(56f, 120f, 90f, 120f, w, c)
            g.line(90f, 120f, 100f, 130f, w, c)
            g.line(184f, 120f, 150f, 120f, w, c)
            g.line(150f, 120f, 140f, 130f, w, c)
            g.circle(120f, 120f, if (pass == 1) 3.2f else 4.6f, c)
        }

        val pc = zone(pitch, PITCH_WARN, PITCH_DANGER)
        g.rrect(60f, 174f, 27f, 17f, 9f, 0f, C.BG, 170)
        g.rrect(180f, 174f, 27f, 17f, 9f, 0f, C.BG, 170)
        g.text(60f, 168f, "крен", F.TINY, C.GRAY)
        g.text(180f, 168f, "тангаж", F.TINY, C.GRAY)
        g.text(60f, 185f, fmtNum(abs(roll).roundToInt().toFloat(), 0, "°"), F.SMALL, if (rc == C.GREEN) C.WHITE else rc)
        g.text(180f, 185f, fmtNum(pitch.roundToInt().toFloat(), 0, "°"), F.SMALL, if (pc == C.GREEN) C.WHITE else pc)

        val slip = sin(a) - m.lat
        g.rrect(120f, 204f, 34f, 8f, 8f, 0f, C.BG, 170)
        g.line(110f, 197f, 110f, 211f, 1.3f, C.WHITE)
        g.line(130f, 197f, 130f, 211f, 1.3f, C.WHITE)
        g.circle(120 + slip.coerceIn(-0.5f, 0.5f) * 52, 204f, 6.2f, C.WHITE)
    }

    // ===================== часы (время магнитолы) =====================
    private fun clockHand(ang: Float, len: Float, w: Float, color: Int) {
        val ca = cos(ang); val sa = sin(ang)
        val neck = 15f
        for (pass in 0..1) {
            val e = if (pass == 1) 0f else 2.4f; val cc = if (pass == 1) color else C.BG
            g.line(120f, 120f, 120 + neck * ca, 120 + neck * sa, 2.6f + e, cc)
            g.line(120 + neck * ca, 120 + neck * sa, 120 + len * ca, 120 + len * sa, w + e, cc)
        }
    }

    private fun pageClock() {
        val cal = Calendar.getInstance()
        val ms = cal.get(Calendar.MILLISECOND)
        val s = cal.get(Calendar.SECOND) + ms / 1000f
        val mi = cal.get(Calendar.MINUTE) + s / 60f
        val h = (cal.get(Calendar.HOUR) % 12) + mi / 60f
        for (i in 0 until 60) {
            val an = (i * 6 - 90) * DEG; val ca = cos(an); val sa = sin(an)
            if (i % 5 == 0) g.line(120 + 98 * ca, 120 + 98 * sa, 120 + 110 * ca, 120 + 110 * sa, 3.2f, C.WHITE)
            else g.line(120 + 104 * ca, 120 + 104 * sa, 120 + 110 * ca, 120 + 110 * sa, 1.2f, C.GRAY2)
        }
        for (i in 1..12) {
            val an = (i * 30 - 90) * DEG
            g.text(120 + 82 * cos(an), 120 + 82 * sin(an) + 7.5f, "$i", F.MED, if (i % 3 == 0) C.WHITE else C.GRAY)
        }
        val yb = 120 - 82 * 0.5f + 7.5f
        g.text(73f, yb, WD_SHORT[(cal.get(Calendar.DAY_OF_WEEK) - 1) % 7], F.MED, C.ORANGE, AL_LEFT)
        g.text(171f, yb, String.format(java.util.Locale.US, "%02d.%02d", cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1), F.MED, C.WHITE, AL_RIGHT)
        clockHand((h * 30 - 90) * DEG, 56f, 7.5f, C.WHITE)
        clockHand((mi * 6 - 90) * DEG, 94f, 6.0f, C.WHITE)
        g.circle(120f, 120f, 5.5f, C.WHITE)
        val an = (s * 6 - 90) * DEG; val ca = cos(an); val sa = sin(an)
        g.line(120 - 20 * ca, 120 - 20 * sa, 120 + 106 * ca, 120 + 106 * sa, 1.8f, C.ORANGE)
        g.circle(120f, 120f, 4.2f, C.ORANGE)
        g.circle(120f, 120f, 1.7f, C.BG)
    }

    // ===================== путь =====================
    private fun niceScale(need: Float): Float {
        val steps = floatArrayOf(50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f, 50000f, 100000f, 200000f)
        for (s in steps) if (need <= s) return s
        return 500000f
    }

    private fun fmtDist(mtr: Float): String =
        if (mtr < 1000) "${mtr.roundToInt()} м" else fmtNum(mtr / 1000f, if (mtr < 10000) 1 else 0, " км")

    private var trkPx = FloatArray(0)
    private var trkPy = FloatArray(0)

    private fun pagePath() {
        val viewR = 84f
        val posX = m.x; val posY = m.y
        var mCount = 0
        val scaleM: Float
        synchronized(link.trackLock) {
            val n = link.trackN
            val tx = link.trackX; val ty = link.trackY
            var far2 = posX * posX + posY * posY
            for (i in 0 until n) {
                val dx = tx[i] - posX; val dy = ty[i] - posY
                val d2 = dx * dx + dy * dy
                if (d2 > far2) far2 = d2
            }
            scaleM = niceScale(sqrt(far2) * 1.05f)
            val k = viewR / scaleM
            if (trkPx.size < n) { trkPx = FloatArray(n + 256); trkPy = FloatArray(n + 256) }
            for (i in 0 until n) {
                val x = 120 + (tx[i] - posX) * k
                val y = 120 - (ty[i] - posY) * k
                if (mCount > 0 && abs(x - trkPx[mCount - 1]) < 1.5f && abs(y - trkPy[mCount - 1]) < 1.5f) continue
                trkPx[mCount] = x; trkPy[mCount] = y; mCount++
            }
        }
        val k = viewR / scaleM

        g.circle(120f, 120f, viewR + 14, C.CARD)
        g.ring(120f, 120f, viewR * 0.5f, 1f, C.TRACK)
        g.ring(120f, 120f, viewR, 1f, C.TRACK)
        g.poly(C.RED, 120f, 120 - viewR - 9, 115f, 120 - viewR + 1, 125f, 120 - viewR + 1)

        for (i in 1 until mCount) g.line(trkPx[i - 1], trkPy[i - 1], trkPx[i], trkPy[i], 4f, C.BLUE)
        if (mCount > 0) g.line(trkPx[mCount - 1], trkPy[mCount - 1], 120f, 120f, 4f, C.BLUE)

        val sx = 120 - posX * k; val sy = 120 + posY * k
        g.circle(sx, sy, 6.5f, C.WHITE)
        g.circle(sx, sy, 4.5f, C.GREEN)

        run {
            val a = (m.hdg - 90) * DEG; val half = 28 * DEG
            g.polyA(C.BLUE, 90, 120f, 120f,
                120 + 30 * cos(a - half), 120 + 30 * sin(a - half),
                120 + 30 * cos(a + half), 120 + 30 * sin(a + half))
            g.circle(120f, 120f, 9f, C.WHITE)
            g.circle(120f, 120f, 6.5f, C.BLUE)
        }

        g.text(120f, 24f, fmtDist(m.odo), F.SMALL, C.WHITE)
        g.text(120f, 213f, "до старта " + fmtDist(sqrt(posX * posX + posY * posY)), F.TINY, C.GRAY)
        g.line(120 - viewR / 4, 196f, 120 + viewR / 4, 196f, 2f, C.GRAY2)
        g.text(120f, 192f, fmtDist(scaleM / 2), F.TINY, C.GRAY2)

        if (m.legacy) {
            g.rrect(120f, 160f, 80f, 13f, 13f, 0f, C.BG, 200)
            g.text(120f, 164f, "трек — с прошивки 3.10", F.TINY, C.ORANGE)
        } else if (!m.can && !m.gpsFresh) {
            g.rrect(120f, 160f, 74f, 13f, 13f, 0f, C.BG, 200)
            g.text(120f, 164f, "нет скорости с CAN", F.TINY, C.ORANGE)
        } else if (m.hs != 2) {
            g.text(120f, 52f, if (m.hs == 3) "курс по GPS" else "курс по гироскопу", F.TINY, C.GRAY2)
        }
    }

    // ===================== приборы =====================
    private fun gaugeColor(v: Float, cold: Float, warn: Float, danger: Float): Int =
        if (!cold.isNaN() && v < cold) C.TEAL else if (v >= danger) C.RED else if (v >= warn) C.YELLOW else C.GREEN

    private fun pageGauge(title: String, unit: String, vmin: Float, vmax: Float, cold: Float, warn: Float, danger: Float,
                          dec: Int, v: Float, valid: Boolean, peak: Float, sub: String) {
        val r = 100f; val w = 13f; val a0 = 135 * DEG; val a1 = 405 * DEG
        g.arc(120f, 120f, r, w, a0, a1, C.TRACK)
        g.text(120f, 70f, title, F.SMALL, C.GRAY)
        g.text(120 + r * cos(a0) + 4, 120 + r * sin(a0) + 22, fmtNum(vmin, 0), F.TINY, C.GRAY2)
        g.text(120 + r * cos(a1) - 4, 120 + r * sin(a1) + 22, fmtNum(vmax, 0), F.TINY, C.GRAY2)
        if (!valid) {
            g.text(120f, 142f, "—", F.HUGE, C.GRAY4)
            g.text(120f, 170f, if (m.legacy && title == "Обороты") "с прошивки 3.10" else "нет данных", F.SMALL, C.GRAY2)
            return
        }
        val t = (v.coerceIn(vmin, vmax) - vmin) / (vmax - vmin)
        val c = gaugeColor(v, cold, warn, danger)
        g.arc(120f, 120f, r, w, a0, a0 + (a1 - a0) * t, c)
        val hasPeak = !peak.isNaN() && peak > vmin
        if (hasPeak) {
            val tp = (peak.coerceIn(vmin, vmax) - vmin) / (vmax - vmin)
            val ap = a0 + (a1 - a0) * tp
            g.circle(120 + r * cos(ap), 120 + r * sin(ap), 3f, C.WHITE)
        }
        g.text(120f, 146f, fmtNum(v, dec), F.HUGE, C.WHITE)
        g.text(120f, 170f, unit, F.SMALL, C.GRAY)
        if (hasPeak) g.text(120f, 190f, "макс " + fmtNum(peak, dec), F.TINY, C.GRAY2)
        if (sub.isNotEmpty()) g.text(120f, 206f, sub, F.TINY, C.GRAY2)
    }

    private fun pageGMeter() {
        for (r in floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f)) g.ring(120f, 120f, r * GM_SCALE, if (r == 1.0f) 1.5f else 1f, C.TRACK)
        g.line(24f, 120f, 216f, 120f, 1f, C.TRACK)
        g.line(120f, 24f, 120f, 216f, 1f, C.TRACK)
        g.text(124f, 120 - 0.5f * GM_SCALE + 12, "0,5", F.TINY, C.GRAY4, AL_LEFT)
        val n = Model.GM_TRAIL
        for (i in 0 until n) {
            val age = (m.gmPos - 1 - i + n) % n
            g.circle(120 + m.gmX[i] * GM_SCALE, 120 - m.gmY[i] * GM_SCALE, 2.2f, C.BLUE, 200 - age * 4)
        }
        val lon = m.lon; val lat = m.lat
        val total = sqrt(lon * lon + lat * lat)
        val c = if (total > 0.6f) C.RED else if (total > 0.35f) C.YELLOW else C.GREEN
        val x = 120 + lat.coerceIn(-1.1f, 1.1f) * GM_SCALE; val y = 120 - lon.coerceIn(-1.1f, 1.1f) * GM_SCALE
        g.circle(x, y, 10f, C.WHITE)
        g.circle(x, y, 7.5f, c)
        g.text(120f, 176f, fmtNum(total, 2, " g"), F.MED, C.WHITE)
        g.text(120f, 40f, fmtNum(m.gmAcc, 2), F.TINY, C.GRAY)
        g.text(120f, 210f, fmtNum(m.gmBrake, 2), F.TINY, C.GRAY)
        g.text(36f, 116f, fmtNum(m.gmLeft, 2), F.TINY, C.GRAY)
        g.text(204f, 116f, fmtNum(m.gmRight, 2), F.TINY, C.GRAY)
    }
}
