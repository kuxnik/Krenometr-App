package ru.diy.krenometr

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.Projection
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt

/** Спутник Esri World Imagery: адрес тайла — z/y/x. */
class EsriImagery : OnlineTileSourceBase(
    "Esri.WorldImagery", 1, 19, 256, ".jpg",
    arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"),
    "© Esri, Maxar, Earthstar Geographics"
) {
    override fun getTileURLString(pMapTileIndex: Long): String =
        baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" + MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
}

/**
 * Экран «Трек» с картой: подложка (топо / OSM / спутник), кэш тайлов и офлайн-архивы .mbtiles,
 * трек поездки (счисление кренометра, привязанное к GPS), своя позиция с лучом курса,
 * поворот «курс вверх» и плашка с креном и дифферентом поверх карты.
 *
 * Привязка: кренометр считает путь в метрах (x — восток, y — север) от старта поездки.
 * По фиксам GPS магнитолы находим, где на Земле этот «ноль»: origin = фикс − (x, y).
 */
@SuppressLint("ViewConstructor")
class MapPage(ctx: Context, private val link: KrenLink, private val m: Model) : FrameLayout(ctx) {
    companion object {
        val SOURCES: Array<ITileSource> by lazy { arrayOf(TileSourceFactory.OpenTopo, TileSourceFactory.MAPNIK, EsriImagery()) }
        val SOURCE_NAMES = arrayOf("Топографическая", "Дорожная (OSM)", "Спутник (Esri)")

        /** Папка карт: сюда же кладутся офлайн-архивы .mbtiles. */
        fun baseDir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "osmdroid")

        fun initConfig(ctx: Context) {
            val c = Configuration.getInstance()
            c.load(ctx, ctx.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
            c.userAgentValue = "Krenometr/1.4 (ru.diy.krenometr)"
            val base = baseDir(ctx)
            base.mkdirs()
            c.osmdroidBasePath = base
            c.osmdroidTileCache = File(base, "tiles")
            c.tileFileSystemCacheMaxBytes = 1500L * 1024 * 1024        // до 1,5 ГБ кэша
            c.tileFileSystemCacheTrimBytes = 1200L * 1024 * 1024
            c.expirationOverrideDuration = 365L * 24 * 3600 * 1000       // скачанное не устаревает год
        }
    }

    val map: MapView
    private val trackLine: Polyline
    private val prefs = ctx.getSharedPreferences("kren", Context.MODE_PRIVATE)

    var follow = true; private set
    var courseUp = prefs.getBoolean("courseUp", true); private set
    var sourceIdx = prefs.getInt("mapSource", 0).coerceIn(0, 2); private set

    // привязка счисления к Земле
    private var originLat = Double.NaN
    private var originLon = Double.NaN
    private var originTrip = Long.MIN_VALUE
    private var builtN = -1
    private var builtTrip = Long.MIN_VALUE
    private var meGeo: GeoPoint? = null
    private var meHdg = 0f
    private var lastFixAt = 0L
    private var lastFix: GeoPoint? = null
    private var firstCentered = false

    private val info = InfoCard(ctx)
    private val btnFollow: Button
    private val btnOrient: Button
    private val btnLayer: Button

    init {
        setBackgroundColor(Color.BLACK)
        map = MapView(ctx)
        map.setTileSource(SOURCES[sourceIdx])
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.isTilesScaledToDpi = true
        map.controller.setZoom(prefs.getFloat("mapZoom", 15f).toDouble())
        map.setMinZoomLevel(3.0)
        map.setMaxZoomLevel(19.0)
        // палец на карте — перестаём следовать за машиной
        map.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_MOVE && follow) { follow = false; updateButtons() }
            false
        }

        trackLine = Polyline(map)
        trackLine.outlinePaint.color = Color.rgb(255, 214, 10)
        trackLine.outlinePaint.strokeWidth = 9f
        trackLine.outlinePaint.strokeCap = Paint.Cap.ROUND
        trackLine.outlinePaint.strokeJoin = Paint.Join.ROUND
        trackLine.outlinePaint.isAntiAlias = true
        map.overlays.add(trackLine)
        map.overlays.add(MeOverlay())
        addView(map, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        addView(info, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(10f); topMargin = dp(10f)
        })

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        btnFollow = button("◎ ко мне") { follow = true; firstCentered = false; updateButtons(); update(true) }
        btnOrient = button("") {
            courseUp = !courseUp
            prefs.edit().putBoolean("courseUp", courseUp).apply()
            if (!courseUp) map.mapOrientation = 0f
            updateButtons()
        }
        btnLayer = button("") {
            sourceIdx = (sourceIdx + 1) % SOURCES.size
            prefs.edit().putInt("mapSource", sourceIdx).apply()
            map.setTileSource(SOURCES[sourceIdx])
            updateButtons()
        }
        for (b in arrayOf(btnLayer, btnOrient, btnFollow))
            col.addView(b, LinearLayout.LayoutParams(dp(150f), dp(48f)).apply { topMargin = dp(8f) })
        addView(col, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = dp(10f); bottomMargin = dp(10f)
        })
        updateButtons()
    }

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(context)
        b.text = text
        b.setAllCaps(false)
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.background = GradientDrawable().apply { setColor(Color.argb(200, 28, 28, 30)); setCornerRadius(dp(12f).toFloat()) }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun updateButtons() {
        btnFollow.setTextColor(if (follow) Color.rgb(10, 132, 255) else Color.WHITE)
        btnOrient.text = if (courseUp) "⬆ курс вверх" else "N север вверх"
        btnLayer.text = "▦ " + SOURCE_NAMES[sourceIdx].substringBefore(' ')
    }

    /** Переподключить офлайн-архивы после копирования нового файла. */
    fun reloadArchives() {
        map.setTileProvider(MapTileProviderBasic(context.applicationContext, SOURCES[sourceIdx]))
        map.invalidate()
    }

    fun onResume() = map.onResume()
    fun onPause() {
        prefs.edit().putFloat("mapZoom", map.zoomLevelDouble.toFloat()).apply()
        map.onPause()
    }

    /** Фикс GPS магнитолы: привязка счисления к Земле. */
    fun onGps(lat: Double, lon: Double, acc: Float) {
        lastFixAt = SystemClock.elapsedRealtime()
        lastFix = GeoPoint(lat, lon)
        val s = link.snap ?: return
        if (s.legacy || acc > 25f) return
        val oLat = lat - s.y / 110540.0
        val oLon = lon - s.x / (111320.0 * cos(Math.toRadians(lat)))
        if (originLat.isNaN() || originTrip != s.tripId) {
            originLat = oLat; originLon = oLon; originTrip = s.tripId; builtN = -1
        } else {
            // кренометр сам подтягивает путь к GPS — здесь только сглаживаем остаток
            originLat += 0.05 * (oLat - originLat)
            originLon += 0.05 * (oLon - originLon)
        }
    }

    private fun toGeo(x: Float, y: Float): GeoPoint {
        val lat = originLat + y / 110540.0
        val lon = originLon + x / (111320.0 * cos(Math.toRadians(originLat)))
        return GeoPoint(lat, lon)
    }

    /** Вызывается из кадра (~5 раз в секунду, пока экран открыт). */
    fun update(force: Boolean = false) {
        val s = link.snap
        val haveOrigin = !originLat.isNaN() && s != null && !s.legacy && s.tripId == originTrip
        // трек — перестраиваем, когда в нём прибавились точки или сменилась поездка
        if (haveOrigin) {
            val n: Int
            val pts = ArrayList<GeoPoint>()
            synchronized(link.trackLock) {
                n = link.trackN
                if (force || n != builtN || builtTrip != originTrip) {
                    pts.ensureCapacity(n + 1)
                    for (i in 0 until n) pts.add(toGeo(link.trackX[i], link.trackY[i]))
                }
            }
            if (force || n != builtN || builtTrip != originTrip) {
                trackLine.setPoints(pts)
                builtN = n; builtTrip = originTrip
            }
            meGeo = toGeo(m.x, m.y)
        } else {
            if (builtN != 0) { trackLine.setPoints(ArrayList()); builtN = 0 }
            meGeo = if (lastFix != null && SystemClock.elapsedRealtime() - lastFixAt < 5000) lastFix else null
        }
        meHdg = m.hdg
        val me = meGeo
        if (me != null && (follow || !firstCentered)) {
            map.controller.setCenter(me)
            firstCentered = true
        }
        if (courseUp) map.mapOrientation = -meHdg
        info.status = when {
            link.inetNet == null -> "нет интернета для карты — видно только скачанное"
            !link.connected -> "нет связи с кренометром"
            s?.legacy == true -> "трек на карте — с прошивки 3.10"
            haveOrigin -> ""
            me != null -> "привязываю трек к GPS…"
            else -> "нет GPS — трек появится после первого фикса"
        }
        info.refresh()
        map.invalidate()
    }

    /** Своя позиция: синяя точка и луч направления (как на экране «Путь» кренометра). */
    private inner class MeOverlay : Overlay() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val pt = Point()
        override fun draw(c: Canvas, pj: Projection) {
            val g = meGeo ?: return
            pj.toPixels(g, pt)
            val d = resources.displayMetrics.density
            // луч: курс машины относительно севера, с учётом поворота карты
            val a = Math.toRadians((meHdg + map.mapOrientation - 90).toDouble())
            val half = Math.toRadians(28.0)
            val r = 46f * d
            path.reset()
            path.moveTo(pt.x.toFloat(), pt.y.toFloat())
            path.lineTo(pt.x + r * cos(a - half).toFloat(), pt.y + r * kotlin.math.sin(a - half).toFloat())
            path.lineTo(pt.x + r * cos(a + half).toFloat(), pt.y + r * kotlin.math.sin(a + half).toFloat())
            path.close()
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 10, 132, 255)
            c.drawPath(path, p)
            p.color = Color.WHITE
            c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), 11f * d, p)
            p.color = Color.rgb(10, 132, 255)
            c.drawCircle(pt.x.toFloat(), pt.y.toFloat(), 8f * d, p)
        }
    }

    /** Плашка поверх карты: крен и дифферент крупно, скорость, поездка. */
    private inner class InfoCard(ctx: Context) : View(ctx) {
        var status = ""
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 0, 0, 0) }
        private val lbl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.GRAY; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
        private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }
        private val r = RectF()

        override fun onMeasure(w: Int, h: Int) {
            val d = resources.displayMetrics.density
            setMeasuredDimension((300 * d).toInt(), ((if (status.isEmpty()) 112 else 136) * d).toInt())
        }

        private var measuredWithStatus = false
        fun refresh() {
            if (status.isNotEmpty() != measuredWithStatus) { measuredWithStatus = status.isNotEmpty(); requestLayout() }
            invalidate()
        }

        private fun col(v: Float, warn: Float, danger: Float): Int {
            val a = abs(v)
            return if (a >= danger) C.RED else if (a >= warn) C.ORANGE else C.GREEN
        }

        override fun onDraw(c: Canvas) {
            val d = resources.displayMetrics.density
            r.set(0f, 0f, width.toFloat(), height.toFloat())
            c.drawRoundRect(r, 16 * d, 16 * d, bg)
            lbl.textSize = 13 * d
            big.textSize = 40 * d
            c.drawText("крен", 14 * d, 22 * d, lbl)
            c.drawText("дифферент", 150 * d, 22 * d, lbl)
            if (m.have) {
                big.color = col(m.roll, Dial.ROLL_WARN, Dial.ROLL_DANGER)
                c.drawText(fmtNum(m.roll.roundToInt().toFloat(), 0, "°"), 14 * d, 66 * d, big)
                big.color = col(m.pitch, Dial.PITCH_WARN, Dial.PITCH_DANGER)
                c.drawText(fmtNum(m.pitch.roundToInt().toFloat(), 0, "°"), 150 * d, 66 * d, big)
            }
            lbl.textSize = 15 * d
            lbl.color = Color.WHITE
            val spd = if (m.can && m.speed >= 0) "${m.speed} км/ч" else if (m.gpsFresh && m.gpsHasSpeed) "${m.gpsSpeedKmh.roundToInt()} км/ч (GPS)" else "— км/ч"
            c.drawText(spd + "   поездка " + fmtNum(m.odo / 1000f, 1, " км"), 14 * d, 96 * d, lbl)
            lbl.color = C.GRAY
            if (status.isNotEmpty()) {
                lbl.textSize = 13 * d
                lbl.color = C.ORANGE
                c.drawText(status, 14 * d, 122 * d, lbl)
                lbl.color = C.GRAY
            }
        }
    }
}
