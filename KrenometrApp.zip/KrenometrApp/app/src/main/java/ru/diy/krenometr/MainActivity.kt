package ru.diy.krenometr

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Choreographer
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var link: KrenLink
    private val model = Model()
    private lateinit var dial: Dial
    private lateinit var dialView: DialView
    private lateinit var panel: PanelView
    private lateinit var gaugeArea: LinearLayout
    private lateinit var mapPage: MapPage
    private var lastMapAt = 0L
    private lateinit var termArea: LinearLayout
    private lateinit var termOut: TextView
    private lateinit var termScroll: ScrollView
    private lateinit var termInput: EditText
    private lateinit var termNote: TextView
    private val tabs = ArrayList<TextView>()

    private var page = Pages.TILT
    private var lastFrameNs = 0L
    private var lastPanelAt = 0L
    private var lastZeroDone = -1L
    private var running = false

    private val prefs by lazy { getSharedPreferences("kren", Context.MODE_PRIVATE) }

    // ---- GPS магнитолы: принимает служба (и шлёт в кренометр), экран только показывает ----
    private val fixListener: (Location) -> Unit = { loc ->
        runOnUiThread {
            model.gpsAt = SystemClock.elapsedRealtime()
            model.gpsAcc = if (loc.hasAccuracy()) loc.accuracy else 99f
            model.gpsHasSpeed = loc.hasSpeed()
            model.gpsSpeedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else -1f
            if (loc.hasAccuracy()) mapPage.onGps(loc.latitude, loc.longitude, loc.accuracy)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Kren.start(this)                                    // служба перезапустит GPS с разрешением
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(now: Long) {
            if (!running) return
            val dt = if (lastFrameNs == 0L) 0.016f else ((now - lastFrameNs) / 1e9f).coerceIn(0.001f, 0.2f)
            lastFrameNs = now
            val s = link.snap
            model.update(if (s != null && link.lastRxAt != 0L && SystemClock.elapsedRealtime() - link.lastRxAt < 10000) s else null, dt)
            if (s != null && !s.legacy) {
                if (lastZeroDone >= 0 && s.zeroDone != lastZeroDone) { model.maxRoll = 0f; model.maxPitch = 0f }
                lastZeroDone = s.zeroDone
            }
            if (page == Pages.TRACK) {
                val t = SystemClock.elapsedRealtime()
                if (t - lastMapAt > 200) { lastMapAt = t; mapPage.update() }
            } else if (page != Pages.TERMINAL) {
                dialView.invalidate()
                val t = SystemClock.elapsedRealtime()
                if (t - lastPanelAt > 100) { lastPanelAt = t; panel.invalidate() }
            } else {
                termNote.text = termNoteText()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        MapPage.initConfig(this)
        link = Kren.link(this)
        prefs.edit().remove("direct").apply()               // «подключаться напрямую» больше нет: Android спрашивал каждый раз
        dial = Dial(model, link)
        page = prefs.getInt("page", Pages.TILT)
        if (page != Pages.TERMINAL && (page < 0 || page >= Pages.COUNT)) page = Pages.TILT
        setContentView(buildUi())
        selectPage(page)
        if (Build.VERSION.SDK_INT >= 23) {
            val need = ArrayList<String>()
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.ACCESS_FINE_LOCATION); need.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
                need.add("android.permission.POST_NOTIFICATIONS")
            if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
        }
    }

    override fun onStart() {
        super.onStart()
        Kren.start(this)                                    // связь и GPS — в фоновой службе
        Kren.fixListeners.add(fixListener)
        running = true
        lastFrameNs = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    override fun onStop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        if (page == Pages.TERMINAL) link.termEnd()
        Kren.fixListeners.remove(fixListener)               // связь и GPS продолжают работать в службе
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        mapPage.onResume()
    }

    override fun onPause() {
        mapPage.onPause()
        super.onPause()
    }

    // ---------------- офлайн-карта: файл .mbtiles с магнитолы или флешки ----------------
    private val REQ_MAP_FILE = 7

    private fun pickOfflineMap() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try { startActivityForResult(i, REQ_MAP_FILE) } catch (e: Exception) { dial.toast("Нет выбора файлов") }
    }

    @Deprecated("startActivityForResult — без AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MAP_FILE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        var name = "map.mbtiles"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (col >= 0 && c.moveToFirst()) name = c.getString(col) ?: name
            }
        } catch (e: Exception) { }
        val low = name.lowercase()
        if (!(low.endsWith(".mbtiles") || low.endsWith(".sqlite") || low.endsWith(".gemf") || low.endsWith(".zip"))) {
            alert("Офлайн-карта", "Нужен файл .mbtiles (или .sqlite/.gemf/.zip в формате osmdroid). Выбран: $name")
            return
        }
        dial.toast("Копирую карту…")
        Thread {
            val res = try {
                val dst = java.io.File(MapPage.baseDir(this), name)
                contentResolver.openInputStream(uri)?.use { inp -> dst.outputStream().use { inp.copyTo(it, 1 shl 16) } }
                "Карта «$name» добавлена (${java.io.File(MapPage.baseDir(this), name).length() / 1048576} МБ)."
            } catch (e: Exception) { "Не удалось скопировать: ${e.message}" }
            runOnUiThread { mapPage.reloadArchives(); alert("Офлайн-карта", res) }
        }.start()
    }

    private fun alert(title: String, msg: String) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); setCornerRadius(dp(radiusDp).toFloat()) }

    // ---------------- интерфейс ----------------
    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Color.BLACK)

        // слева — список экранов
        val tabCol = LinearLayout(this)
        tabCol.orientation = LinearLayout.VERTICAL
        tabCol.setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
        val names = Pages.NAMES.toMutableList()
        names.add("Терминал")
        for (i in names.indices) {
            val p = if (i < Pages.COUNT) i else Pages.TERMINAL
            val t = TextView(this)
            t.text = names[i]
            t.textSize = 15f
            t.setTextColor(C.GRAY)
            t.gravity = Gravity.CENTER_VERTICAL
            t.setPadding(dp(12f), dp(9f), dp(12f), dp(9f))
            t.tag = p
            t.setOnClickListener { selectPage(p) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(3f)
            tabCol.addView(t, lp)
            tabs.add(t)
        }
        val gear = TextView(this)
        gear.text = "⚙ Настройки"
        gear.textSize = 15f
        gear.setTextColor(C.BLUE)
        gear.setPadding(dp(12f), dp(12f), dp(12f), dp(9f))
        gear.setOnClickListener { showSettings() }
        tabCol.addView(gear)
        val tabScroll = ScrollView(this)
        tabScroll.isVerticalScrollBarEnabled = false
        tabScroll.addView(tabCol)
        root.addView(tabScroll, LinearLayout.LayoutParams(dp(150f), LinearLayout.LayoutParams.MATCH_PARENT))

        // прибор + панель
        gaugeArea = LinearLayout(this)
        gaugeArea.orientation = LinearLayout.HORIZONTAL
        dialView = DialView(this, dial, link)
        dialView.onPageSwipe = { d ->
            val cur = if (page == Pages.TERMINAL) 0 else page
            selectPage((cur + d + Pages.COUNT) % Pages.COUNT)
        }
        dialView.onTap = {
            model.resetPeaks(page)
            if (page in intArrayOf(Pages.TILT, Pages.HORIZON, Pages.GMETER))
                dial.toast("Максимумы сброшены")
        }
        dialView.onLong = { longAction() }
        gaugeArea.addView(dialView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT))
        panel = PanelView(this, model, link)
        gaugeArea.addView(panel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))

        termArea = buildTerminal()
        termArea.visibility = View.GONE
        mapPage = MapPage(this, link, model)
        mapPage.visibility = View.GONE

        val content = FrameLayout(this)
        content.addView(gaugeArea, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        content.addView(termArea, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        content.addView(mapPage, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.addView(content, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        return root
    }

    private fun selectPage(p: Int) {
        val wasTerm = page == Pages.TERMINAL
        page = p
        prefs.edit().putInt("page", p).apply()
        for (t in tabs) {
            val sel = t.tag == p
            t.setTextColor(if (sel) Color.WHITE else C.GRAY)
            t.background = if (sel) rounded(C.CARD, 10f) else null
            t.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        val term = p == Pages.TERMINAL
        val mapOn = p == Pages.TRACK
        gaugeArea.visibility = if (term || mapOn) View.GONE else View.VISIBLE
        termArea.visibility = if (term) View.VISIBLE else View.GONE
        mapPage.visibility = if (mapOn) View.VISIBLE else View.GONE
        if (mapOn) mapPage.update(true)
        if (!term && !mapOn) dialView.page = p
        link.wantWheels = p == Pages.WHEELS
        if (wasTerm && !term) link.termEnd()                // опрос машины — сразу, не ждать минуту
    }

    private fun longAction() {
        when (page) {
            Pages.TILT, Pages.HORIZON, Pages.WHEELS -> confirm("Обнулить углы?",
                "Машина должна стоять на ровном месте. Текущее положение станет нулём крена и дифферента.") {
                link.async("/zero") { r -> dial.toast(if (r != null) "Ноль установлен" else "Нет связи") }
                model.maxRoll = 0f; model.maxPitch = 0f
            }
            Pages.NAV, Pages.TRACK -> confirm("Начать новую поездку?", "Счётчик поездки и трек обнулятся. Общий пробег и моточасы не меняются.") {
                link.async("/trip") { r -> dial.toast(if (r != null) "Новая поездка" else "Нет связи") }
            }
        }
    }

    private fun confirm(title: String, msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title).setMessage(msg)
            .setPositiveButton("Да") { _, _ -> ok() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------------- настройки ----------------
    private fun showSettings() {
        val scrOn = model.screenOn
        val apAlways = model.apAlways
        val items = arrayOf(
            if (scrOn) "Выключить экран кренометра" else "Включить экран кренометра",
            if (apAlways) "Сеть Krenometr: всегда (сейчас) → 10 минут" else "Сеть Krenometr: 10 минут (сейчас) → всегда",
            "Обнулить углы",
            "Начать новую поездку",
            "Передать время магнитолы в кренометр",
            "Пробег и моточасы…",
            "Офлайн-карта: добавить файл .mbtiles",
            "Повернуть экран кренометра на 90°",
            "Выйти и остановить связь",
            "О кренометре",
            "Лог USB (что присылает плата)"
        )
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Кренометр")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> link.async("/scr?on=" + (if (scrOn) 0 else 1)) { r -> dial.toast(if (r == null) "Нет связи" else if (r.trim() == "1") "Экран включён" else "Экран выключен") }
                    1 -> link.async("/ap?on=" + (if (apAlways) 0 else 1)) { r -> dial.toast(if (r == null) "Нет связи" else "Сохранено") }
                    2 -> { selectPage(Pages.TILT); longAction() }
                    3 -> { selectPage(Pages.NAV); longAction() }
                    4 -> { link.sendTime(); dial.toast("Время передано") }
                    5 -> showOdoSet()
                    6 -> pickOfflineMap()
                    7 -> link.async("/rot", null)
                    8 -> { Kren.stop(this); finishAffinity() }
                    9 -> showInfo()
                    10 -> showUsbLog()
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    /** Выставить общий пробег и моточасы как на приборке машины. */
    private fun showOdoSet() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20f), dp(8f), dp(20f), 0)
        fun field(hint: String, value: String): EditText {
            val l = TextView(this); l.text = hint; l.setTextColor(C.GRAY); col.addView(l)
            val e = EditText(this)
            e.setText(value)
            e.setTextColor(Color.WHITE)
            e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            col.addView(e)
            return e
        }
        val km = field("Пробег по одометру машины, км", if (model.totalKm >= 0) String.format(java.util.Locale.US, "%.1f", model.totalKm) else "")
        val mh = field("Моточасы", if (model.engineH >= 0) String.format(java.util.Locale.US, "%.1f", model.engineH) else "")
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Пробег и моточасы")
            .setView(col)
            .setPositiveButton("Сохранить") { _, _ ->
                val k = km.text.toString().trim().replace(',', '.')
                val h = mh.text.toString().trim().replace(',', '.')
                val q = StringBuilder("/odo?")
                if (k.toDoubleOrNull() != null) q.append("km=").append(k)
                if (h.toDoubleOrNull() != null) { if (q.length > 5) q.append('&'); q.append("mh=").append(h) }
                link.async(q.toString()) { r -> dial.toast(if (r != null) "Сохранено" else "Нет связи") }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showUsbLog() {
        val tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 12f
        tv.setTextColor(Color.rgb(48, 209, 88))
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
        val bad = if (link.usbLastBad.isNotEmpty()) "\n\nПоследний битый пакет:\n" + link.usbLastBad else ""
        tv.text = (link.usb.logText().ifEmpty { "(пусто: кроме пакетов данных, ничего не приходило)" }) + bad
        val sv = ScrollView(this)
        sv.addView(tv)
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Лог USB · строк ${link.usb.rxLines}, пакетов ${link.usbJsonOk}")
            .setView(sv)
            .setPositiveButton("OK", null).show()
    }

    private fun showInfo() {
        link.async("/info") { r ->
            val txt = StringBuilder()
            if (r == null) txt.append("Кренометр не отвечает.\n")
            else try {
                val j = org.json.JSONObject(r)
                txt.append("Прошивка: ").append(j.optString("fw")).append('\n')
                txt.append("Адаптер: ").append(j.optString("elm").ifEmpty { "—" }).append('\n')
                txt.append("Канал Wi-Fi адаптера: ").append(j.optInt("ch").let { if (it == 0) "ещё не найден" else "$it" }).append('\n')
                txt.append("Экран: ").append(if (j.optInt("scr") != 0) "вкл" else "выкл").append('\n')
                txt.append("Сеть Krenometr: ").append(if (j.optInt("ap") != 0) "всегда" else "10 минут").append('\n')
            } catch (e: Exception) {
                txt.append("Прошивка 3.9 или старше: /info нет.\n")
            }
            txt.append("\nИнтернет для карты: ").append(link.inetLabel)
            txt.append("\nСвязь: ").append(link.transport)
            val u = link.usb
            txt.append("\nUSB: ").append(u.status)
            txt.append("\n   устройства: ").append(u.seen)
            txt.append("\n   принято: ").append(u.rxBytes).append(" байт, строк ").append(u.rxLines)
                .append(if (u.txFails > 0) ", ошибок отправки ${u.txFails}" else "")
            txt.append("\n   пакетов данных: ").append(link.usbJsonOk).append(if (link.usbJsonBad > 0) ", битых ${link.usbJsonBad}" else "")
            if (u.open && u.rxLines == 0L) txt.append("\n   плата молчит — на ней прошивка 3.11 или новее?")
            if (u.open && u.rxLines > 0 && link.usbJsonOk == 0L) txt.append("\n   строки идут, но пакетов нет — см. «Лог USB»")
            txt.append("\nGPS магнитолы: ").append(if (model.gpsFresh) "±${model.gpsAcc.toInt()} м" else "нет фикса")
            txt.append("\nКарта microSD: ").append(when (model.sd) { 1 -> "пишется"; 2 -> "ошибка записи"; else -> "нет" })
            val maps = MapPage.baseDir(this).listFiles()?.filter { it.isFile }?.joinToString { it.name } ?: ""
            txt.append("\nОфлайн-карты: ").append(maps.ifEmpty { "нет" })
            txt.append("\nПриложение 1.8")
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("О кренометре").setMessage(txt.toString())
                .setPositiveButton("OK", null).show()
        }
    }

    // ---------------- терминал ----------------
    private fun buildTerminal(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8f), dp(8f), dp(8f), dp(8f))

        termNote = TextView(this)
        termNote.textSize = 13f
        termNote.setTextColor(C.GRAY)
        col.addView(termNote)

        val quick = LinearLayout(this)
        quick.orientation = LinearLayout.HORIZONTAL
        for (cmd in arrayOf("ATRV", "ATI", "ATSH7E0", "0100", "0105", "ATSH7E1", "2102", "ATSH784", "2120", "03", "ATDP")) {
            val b = Button(this)
            b.text = cmd
            b.setAllCaps(false)
            b.textSize = 14f
            b.setTextColor(Color.WHITE)
            b.background = rounded(Color.rgb(44, 44, 46), 8f)
            b.setPadding(dp(12f), 0, dp(12f), 0)
            b.setOnClickListener { termRun(cmd) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42f))
            lp.rightMargin = dp(6f)
            quick.addView(b, lp)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(quick)
        col.addView(hs, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6f) })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        termInput = EditText(this)
        termInput.hint = "команда, напр. ATSH7E1 или 2102"
        termInput.setTextColor(Color.WHITE)
        termInput.setHintTextColor(C.GRAY2)
        termInput.textSize = 18f
        termInput.typeface = Typeface.MONOSPACE
        termInput.setSingleLine(true)
        termInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        termInput.imeOptions = EditorInfo.IME_ACTION_SEND
        termInput.setOnEditorActionListener { _, actionId, ev ->
            if (actionId == EditorInfo.IME_ACTION_SEND || (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)) {
                sendInput(); true
            } else false
        }
        row.addView(termInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val send = Button(this)
        send.text = "Отправить"
        send.setAllCaps(false)
        send.setTextColor(Color.WHITE)
        send.background = rounded(C.BLUE, 10f)
        send.setOnClickListener { sendInput() }
        row.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48f)).apply { leftMargin = dp(8f) })
        val clr = Button(this)
        clr.text = "Очистить"
        clr.setAllCaps(false)
        clr.setTextColor(Color.WHITE)
        clr.background = rounded(Color.rgb(44, 44, 46), 10f)
        clr.setOnClickListener { termOut.text = "" }
        row.addView(clr, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48f)).apply { leftMargin = dp(8f) })
        col.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6f) })

        termOut = TextView(this)
        termOut.typeface = Typeface.MONOSPACE
        termOut.textSize = 15f
        termOut.setTextColor(Color.rgb(48, 209, 88))
        termOut.setTextIsSelectable(true)
        termScroll = ScrollView(this)
        termScroll.background = rounded(Color.rgb(12, 12, 14), 10f)
        termScroll.setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
        termScroll.addView(termOut)
        col.addView(termScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8f) })
        return col
    }

    private fun termNoteText(): String {
        if (!link.connected) return "Нет связи с кренометром. Команды идут через него в ELM327."
        if (link.usbLive && model.elm == 3) return "По USB. ELM327 подключён" + (if (model.termPause) ", опрос машины на паузе." else ".")
        if (model.legacy) return "Прошивка 3.9: терминал работает, опрос машины встаёт на минуту после команды."
        return when (model.elm) {
            3 -> if (model.termPause) "ELM327 подключён. Опрос машины на паузе, пока открыт терминал."
                 else "ELM327 подключён. Первая команда поставит опрос машины на паузу."
            2 -> "ELM327 подключён, ЭБУ молчат (зажигание выключено?). AT-команды работают."
            1 -> "Сеть адаптера есть, но он не принимает соединение."
            else -> "Кренометр ищет сеть адаптера ELM327."
        }
    }

    private fun sendInput() {
        val c = termInput.text.toString().trim()
        if (c.isEmpty()) return
        termInput.setText("")
        termRun(c)
    }

    private fun termRun(cmd: String) {
        val c = cmd.uppercase()
        append("> $c")
        link.termSend(c) { res -> append(res) }
    }

    private fun append(s: String) {
        termOut.append(s + "\n")
        val t = termOut.text
        if (t.length > 20000) termOut.text = t.subSequence(t.length - 15000, t.length)
        termScroll.post { termScroll.fullScroll(View.FOCUS_DOWN) }
    }
}
