package ru.diy.krenometr

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import java.io.ByteArrayOutputStream

/**
 * Кабель USB к кренометру: встроенный USB ESP32-S3 (USB Serial/JTAG, VID 0x303A) — это CDC-ACM.
 * Драйвер не нужен: берём интерфейс данных CDC и читаем/пишем его bulk-точки.
 * Линиями DTR/RTS не управляем — их сочетание у ESP32 может перезагрузить плату.
 */
class UsbLink(ctx: Context, private val onLine: (String) -> Unit) {
    companion object {
        const val VID_ESPRESSIF = 0x303A
        const val ACTION_PERMISSION = "ru.diy.krenometr.USB_PERMISSION"
    }

    private val app = ctx.applicationContext
    private val um = app.getSystemService(Context.USB_SERVICE) as UsbManager

    @Volatile var open = false; private set
    @Volatile var deviceName = ""; private set
    @Volatile private var conn: UsbDeviceConnection? = null
    @Volatile private var epIn: UsbEndpoint? = null
    @Volatile private var epOut: UsbEndpoint? = null
    private var intf: UsbInterface? = null
    @Volatile private var running = false
    private var thread: Thread? = null
    private val writeLock = Any()
    private val asked = HashSet<String>()
    private var registered = false

    private val detachRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                close()
                synchronized(asked) { asked.clear() }   // вставят снова — спросим разрешение снова
            }
        }
    }

    fun start() {
        if (running) return
        running = true
        try {
            val f = IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED)
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(detachRx, f, Context.RECEIVER_EXPORTED)
            else app.registerReceiver(detachRx, f)
            registered = true
        } catch (e: Exception) { }
        val t = Thread({ loop() }, "kren-usb")
        t.isDaemon = true
        t.start()
        thread = t
    }

    fun stop() {
        running = false
        if (registered) { try { app.unregisterReceiver(detachRx) } catch (e: Exception) { }; registered = false }
        close()
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        val buf = ByteArray(16384)
        val line = ByteArrayOutputStream(1024)
        var lastCheck = 0L
        while (running) {
            try {
                if (!open) {
                    tryOpen()
                    if (!open) { Thread.sleep(1000); continue }
                    line.reset()
                }
                val c = conn
                val ep = epIn
                if (c == null || ep == null) { close(); continue }
                val n = c.bulkTransfer(ep, buf, buf.size, 200)
                if (n > 0) {
                    for (i in 0 until n) {
                        val b = buf[i]
                        if (b == '\n'.code.toByte()) {
                            if (line.size() > 0) {
                                val s = String(line.toByteArray(), Charsets.UTF_8)
                                line.reset()
                                try { onLine(s) } catch (e: Exception) { }
                            }
                        } else if (b != '\r'.code.toByte()) {
                            if (line.size() < 262144) line.write(b.toInt())
                        }
                    }
                } else {
                    // -1 бывает и по таймауту: раз в секунду проверяем, что устройство на месте
                    val now = System.currentTimeMillis()
                    if (now - lastCheck > 1000) {
                        lastCheck = now
                        if (um.deviceList.values.none { it.deviceName == deviceName }) close()
                    }
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                close()
                try { Thread.sleep(500) } catch (x: InterruptedException) { break }
            }
        }
    }

    private fun tryOpen() {
        val dev = um.deviceList.values.firstOrNull { it.vendorId == VID_ESPRESSIF } ?: return
        if (!um.hasPermission(dev)) {
            val first = synchronized(asked) { asked.add(dev.deviceName) }
            if (first) {
                val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
                val pi = PendingIntent.getBroadcast(app, 0, Intent(ACTION_PERMISSION).setPackage(app.packageName), flags)
                try { um.requestPermission(dev, pi) } catch (e: Exception) { }
            }
            return
        }
        // интерфейс данных CDC с двумя bulk-точками
        var di: UsbInterface? = null
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (k in 0 until dev.interfaceCount) {
            val itf = dev.getInterface(k)
            if (itf.interfaceClass != UsbConstants.USB_CLASS_CDC_DATA) continue
            var a: UsbEndpoint? = null
            var b: UsbEndpoint? = null
            for (j in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(j)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) a = ep else b = ep
            }
            if (a != null && b != null) { di = itf; inEp = a; outEp = b; break }
        }
        if (di == null) return
        val c = um.openDevice(dev) ?: return
        if (!c.claimInterface(di, true)) { c.close(); return }
        intf = di
        epIn = inEp
        epOut = outEp
        conn = c
        deviceName = dev.deviceName
        open = true
    }

    fun write(s: String): Boolean {
        synchronized(writeLock) {
            val c = conn ?: return false
            val ep = epOut ?: return false
            val b = s.toByteArray(Charsets.UTF_8)
            var off = 0
            while (off < b.size) {
                val n = c.bulkTransfer(ep, b, off, b.size - off, 300)
                if (n <= 0) return false
                off += n
            }
            return true
        }
    }

    fun close() {
        synchronized(writeLock) {
            open = false
            val c = conn
            conn = null
            epIn = null
            epOut = null
            if (c != null) {
                try { intf?.let { c.releaseInterface(it) } } catch (e: Exception) { }
                try { c.close() } catch (e: Exception) { }
            }
            intf = null
        }
    }
}
