package ru.diy.krenometr

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Общее для экрана и фоновой службы: связь с кренометром и GPS магнитолы живут, пока работает служба,
 * а не пока открыт экран. Иначе, стоит переключиться на навигатор, кренометр остаётся без скорости
 * GPS и трек рвётся.
 */
object Kren {
    @Volatile private var linkRef: KrenLink? = null
    fun link(ctx: Context): KrenLink = linkRef ?: synchronized(this) {
        linkRef ?: KrenLink(ctx.applicationContext).also { linkRef = it }
    }

    @Volatile var lastFix: Location? = null
    val fixListeners = CopyOnWriteArrayList<(Location) -> Unit>()

    fun hasLocation(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun start(ctx: Context) {
        val i = Intent(ctx, KrenService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        } catch (e: Exception) {
            link(ctx).start()                               // служба не стартовала — хотя бы связь
        }
    }

    fun stop(ctx: Context) {
        try { ctx.stopService(Intent(ctx, KrenService::class.java)) } catch (e: Exception) { }
    }
}

/** Фоновая служба: связь (USB / Wi-Fi) и GPS магнитолы → кренометр, с уведомлением в шторке. */
class KrenService : Service() {
    companion object {
        const val CHANNEL = "kren"
        const val NOTE_ID = 1
    }

    private var gpsOn = false
    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            Kren.lastFix = loc
            if (loc.hasAccuracy() && loc.accuracy < 50f)
                Kren.link(this@KrenService).sendGps(loc.latitude, loc.longitude, loc.accuracy,
                    if (loc.hasSpeed()) loc.speed else -1f,
                    if (loc.hasBearing() && loc.hasSpeed() && loc.speed >= 3f) loc.bearing else -1f)
            for (l in Kren.fixListeners) try { l(loc) } catch (e: Exception) { }
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("старые Android вызывают его")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        Kren.link(this).start()
        startGps()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()                                      // разрешение на геопозицию могли дать позже
        startGps()
        return START_STICKY
    }

    override fun onDestroy() {
        stopGps()
        Kren.link(this).stop()
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Кренометр", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val note = b.setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Кренометр")
            .setContentText("Связь с кренометром и GPS — в фоне")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                if (Kren.hasLocation(this)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                startForeground(NOTE_ID, note, type)
            } else startForeground(NOTE_ID, note)
        } catch (e: Exception) {
            try { startForeground(NOTE_ID, note) } catch (x: Exception) { }
        }
    }

    private fun startGps() {
        if (gpsOn || !Kren.hasLocation(this)) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            // как можно чаще: многие GPS магнитол дают 5–10 фиксов в секунду
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 200L, 0f, listener)
            gpsOn = true
        } catch (e: Exception) { }
    }

    private fun stopGps() {
        if (!gpsOn) return
        try { (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(listener) } catch (e: Exception) { }
        gpsOn = false
    }
}
