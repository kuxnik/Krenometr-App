package ru.diy.krenometr

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/** Один пакет от кренометра (UDP, прошивка 3.10+) или ответ /a старой прошивки. */
class Snap(
    val n: Long,
    val cal: Boolean, val imu: Boolean,
    val roll: Float, val pitch: Float, val lon: Float, val lat: Float,
    val hdg: Float, val hs: Int, val ma: Int, val bn: Int, val ts: Int,
    val x: Float, val y: Float, val odo: Float, val tripId: Long, val trackN: Int,
    val elm: Int, val can: Boolean,
    val speed: Int, val rpm: Int, val boost: Float, val boostOk: Boolean,
    val cool: Int, val iat: Int, val volt: Float, val atf: Int,
    val wheels: IntArray, val wheelAge: Long,
    val screenOn: Boolean, val apAlways: Boolean, val zeroDone: Long, val termPause: Boolean,
    val legacy: Boolean,
    val gpsAcc: Float = -1f,
    val totalKm: Double = -1.0, val engineH: Double = -1.0, val sd: Int = 0
) {
    companion object {
        fun parse(j: JSONObject): Snap {
            val w = j.optJSONArray("w")
            val wh = IntArray(4) { if (w != null && it < w.length()) w.optInt(it) else 0 }
            return Snap(
                n = j.optLong("n"),
                cal = j.optInt("cal") != 0, imu = j.optInt("imu", 1) != 0,
                roll = j.optDouble("r").toFloat(), pitch = j.optDouble("p").toFloat(),
                lon = j.optDouble("lo").toFloat(), lat = j.optDouble("la").toFloat(),
                hdg = j.optDouble("h").toFloat(), hs = j.optInt("hs"), ma = j.optInt("ma"),
                bn = j.optInt("bn", -1), ts = j.optInt("ts"),
                x = j.optDouble("x").toFloat(), y = j.optDouble("y").toFloat(), odo = j.optDouble("o").toFloat(),
                tripId = j.optLong("ti"), trackN = j.optInt("tn"),
                elm = j.optInt("e", -1), can = j.optInt("c") != 0,
                speed = j.optInt("sp", -1), rpm = j.optInt("rpm", -1),
                boost = j.optDouble("bo").toFloat(), boostOk = j.optInt("bok") != 0,
                cool = j.optInt("cl", -999), iat = j.optInt("ia", -999),
                volt = j.optDouble("u", -1.0).toFloat(), atf = j.optInt("f", -999),
                wheels = wh, wheelAge = j.optLong("wa", -1),
                screenOn = j.optInt("scr", 1) != 0, apAlways = j.optInt("ap", 1) != 0,
                zeroDone = j.optLong("zd"), termPause = j.optInt("tm") != 0,
                legacy = false,
                gpsAcc = j.optDouble("ga", -1.0).toFloat(),
                totalKm = j.optDouble("tot", -1.0), engineH = j.optDouble("mh", -1.0), sd = j.optInt("sd")
            )
        }

        /** Ответ /a прошивки 3.9: без колёс, G, оборотов и трека. */
        fun parseLegacy(j: JSONObject, n: Long): Snap {
            val c = j.optInt("c") != 0
            val t = j.optInt("t", -999)
            val f = j.optInt("f", -999)
            val u = j.optDouble("u", -1.0).toFloat()
            return Snap(
                n = n, cal = false, imu = true,
                roll = j.optDouble("r").toFloat(), pitch = j.optDouble("p").toFloat(), lon = 0f, lat = 0f,
                hdg = j.optDouble("h").toFloat(), hs = j.optInt("hs"), ma = 3,
                bn = j.optInt("bn", -1), ts = j.optInt("ts"),
                x = 0f, y = 0f, odo = j.optDouble("o").toFloat(), tripId = -1, trackN = 0,
                elm = j.optInt("e", -1), can = c,
                speed = if (c) j.optInt("s") else -1, rpm = -1,
                boost = j.optDouble("b").toFloat(), boostOk = c && j.optInt("m") != 0,
                cool = if (c && t > -100) t else -999, iat = -999,
                volt = if (c && u > 0) u else -1f, atf = if (f > -100) f else -999,
                wheels = IntArray(4), wheelAge = -1,
                screenOn = true, apAlways = false, zeroDone = 0, termPause = false,
                legacy = true
            )
        }
    }
}

/** Значения для экрана: плавные (между пакетами), максимумы, след G-метра, отклонения колёс. */
class Model {
    var have = false
    var cal = false
    var imu = true
    var legacy = false

    var roll = 0f; var pitch = 0f; var lon = 0f; var lat = 0f; var hdg = 0f
    var hs = 0; var ma = 0; var bn = -1; var ts = 1
    var x = 0f; var y = 0f; var odo = 0f
    var elm = -1; var can = false
    var speed = -1; var rpm = -1; var boost = 0f; var boostOk = false
    var cool = -999; var iat = -999; var volt = -1f; var atf = -999
    var screenOn = true; var apAlways = true; var termPause = false
    var espGpsAcc = -1f                 // кренометр получает GPS (точность, м) или -1
    var totalKm = -1.0; var engineH = -1.0; var sd = 0

    // GPS магнитолы (заполняет MainActivity)
    var gpsAt = 0L; var gpsAcc = -1f; var gpsSpeedKmh = -1f; var gpsHasSpeed = false
    val gpsFresh: Boolean get() = gpsAt != 0L && android.os.SystemClock.elapsedRealtime() - gpsAt < 3000

    var maxRoll = 0f; var maxPitch = 0f
    var peakBoost = 0f; var peakCool = Float.NaN; var peakRpm = 0f
    var gmAcc = 0f; var gmBrake = 0f; var gmLeft = 0f; var gmRight = 0f

    val wheelDev = FloatArray(4)
    var wheelsFresh = false
    var wheelsMoving = false

    // след G-метра (lat, lon) — 40 последних пакетов
    val gmX = FloatArray(GM_TRAIL)
    val gmY = FloatArray(GM_TRAIL)
    var gmPos = 0
    private var gmInit = false

    private var lastN = Long.MIN_VALUE
    private var lastSnap: Snap? = null
    private var tgtRoll = 0f; private var tgtPitch = 0f; private var tgtLon = 0f; private var tgtLat = 0f; private var tgtHdg = 0f

    fun resetPeaks(page: Int) {
        when (page) {
            Pages.TILT, Pages.HORIZON -> { maxRoll = 0f; maxPitch = 0f }
            Pages.GMETER -> { gmAcc = 0f; gmBrake = 0f; gmLeft = 0f; gmRight = 0f }
        }
    }

    /** Вызывается каждый кадр. dt — секунды с прошлого кадра. */
    fun update(s: Snap?, dt: Float) {
        if (s == null) { have = false; return }
        if (s.n != lastN || s !== lastSnap) {
            lastN = s.n; lastSnap = s
            onPacket(s)
        }
        // плавный ход между пакетами (25 Гц → 60 кадров)
        val k = 1f - exp(-dt / 0.07f)
        if (!have) { roll = tgtRoll; pitch = tgtPitch; lon = tgtLon; lat = tgtLat; hdg = tgtHdg }
        roll += k * (tgtRoll - roll)
        pitch += k * (tgtPitch - pitch)
        lon += k * (tgtLon - lon)
        lat += k * (tgtLat - lat)
        var dh = tgtHdg - hdg
        while (dh > 180f) dh -= 360f
        while (dh < -180f) dh += 360f
        hdg = wrap360(hdg + k * dh)
        have = true

        // колёса — как на экране кренометра: опора — медиана, сглаживание 0,4 с
        val w = s.wheels
        wheelsFresh = s.wheelAge in 0..1500
        val srt = w.map { it.toFloat() }.sorted()
        val avg = (srt[1] + srt[2]) / 2f
        wheelsMoving = wheelsFresh && avg >= 3f
        val kw = min(1f, dt / 0.4f)
        for (i in 0 until 4) {
            val target = if (wheelsMoving) (w[i] - avg) / avg else 0f
            wheelDev[i] += kw * (target - wheelDev[i])
        }
    }

    private fun onPacket(s: Snap) {
        cal = s.cal; imu = s.imu; legacy = s.legacy
        tgtRoll = s.roll; tgtPitch = s.pitch; tgtLon = s.lon; tgtLat = s.lat; tgtHdg = s.hdg
        hs = s.hs; ma = s.ma; bn = s.bn; ts = s.ts
        x = s.x; y = s.y; odo = s.odo
        elm = s.elm; can = s.can
        speed = s.speed; rpm = s.rpm; boost = s.boost; boostOk = s.boostOk
        cool = s.cool; iat = s.iat; volt = s.volt; atf = s.atf
        screenOn = s.screenOn; apAlways = s.apAlways; termPause = s.termPause
        espGpsAcc = s.gpsAcc
        totalKm = s.totalKm; engineH = s.engineH; sd = s.sd

        if (!s.cal) {
            maxRoll = max(maxRoll, abs(s.roll))
            maxPitch = max(maxPitch, abs(s.pitch))
        }
        if (boostOk) peakBoost = max(peakBoost, boost)
        if (cool > -100) peakCool = if (peakCool.isNaN()) cool.toFloat() else max(peakCool, cool.toFloat())
        if (rpm >= 0) peakRpm = max(peakRpm, rpm.toFloat())

        val gx = s.lat.coerceIn(-1.1f, 1.1f)
        val gy = s.lon.coerceIn(-1.1f, 1.1f)
        if (!gmInit) { gmX.fill(gx); gmY.fill(gy); gmInit = true }
        gmX[gmPos] = gx; gmY[gmPos] = gy; gmPos = (gmPos + 1) % GM_TRAIL
        gmAcc = max(gmAcc, s.lon); gmBrake = max(gmBrake, -s.lon)
        gmLeft = max(gmLeft, -s.lat); gmRight = max(gmRight, s.lat)
    }

    companion object {
        const val GM_TRAIL = 40
        fun wrap360(a: Float): Float { val r = a % 360f; return if (r < 0f) r + 360f else r }
    }
}

object Pages {
    const val TILT = 0
    const val WHEELS = 1
    const val HORIZON = 2
    const val NAV = 3          // одометр + компас (как на кренометре)
    const val TRACK = 4        // трек поездки — только в приложении
    const val CLOCK = 5
    const val GMETER = 6
    const val COUNT = 7
    const val TERMINAL = 100

    val NAMES = arrayOf("Кренометр", "Колёса", "Горизонт", "Одометр", "Трек", "Часы", "G-метр")
}
