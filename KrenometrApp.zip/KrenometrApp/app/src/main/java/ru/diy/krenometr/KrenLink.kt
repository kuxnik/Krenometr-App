package ru.diy.krenometr

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.util.TimeZone
import java.util.concurrent.Executors
import kotlin.math.hypot

/**
 * Связь с кренометром: по кабелю USB (основной канал, прошивка 3.11+) или по его сети
 * «Krenometr» (192.168.4.1), если кабеля нет.
 *
 * Магнитола берёт интернет с SIM-карты, а Wi-Fi «Krenometr» — без интернета. Android в такой
 * ситуации ведёт обычный трафик через SIM, поэтому все сокеты приложения явно привязываются
 * к Wi-Fi сети (Network.bindSocket / openConnection). Запрос сети (requestNetwork) заодно
 * не даёт системе отключить «бесполезный» Wi-Fi.
 */
class KrenLink(ctx: Context) {
    companion object {
        const val HOST = "192.168.4.1"
        const val UDP_PORT = 4210
        const val SSID = "Krenometr"
        const val PASS = "krenometr123"
        const val TRACK_STEP_M = 5f
    }

    private val app = ctx.applicationContext
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val trackIo = Executors.newSingleThreadExecutor()

    @Volatile var snap: Snap? = null
    @Volatile var lastRxAt = 0L
    @Volatile var network: Network? = null
    @Volatile var wantWheels = false
    @Volatile var fwInfo = ""

    // ---- USB ----
    val usb = UsbLink(ctx) { onUsbLine(it) }
    @Volatile var usbLastRx = 0L
    /** Данные идут по кабелю (последний пакет не старше 1,5 с). */
    val usbLive: Boolean get() = usb.open && usbLastRx != 0L && SystemClock.elapsedRealtime() - usbLastRx < 1500
    private val usbLock = Object()
    private var usbReqId = 0
    private val usbReplies = HashMap<Int, String>()
    @Volatile private var udpSock: DatagramSocket? = null
    private val gpsIo = Executors.newSingleThreadExecutor()

    /** Как сейчас идут данные: для строки состояния. */
    val transport: String get() = when {
        !connected -> "нет связи"
        usbLive -> "USB"
        snap?.legacy == true -> "Wi-Fi (прошивка 3.9)"
        else -> "Wi-Fi"
    }

    @Volatile private var running = false
    private var thread: Thread? = null
    private var directRequested = false

    // трек текущей поездки (метры: x — восток, y — север)
    val trackLock = Any()
    var trackX = FloatArray(4096); private set
    var trackY = FloatArray(4096); private set
    var trackN = 0; private set
    @Volatile private var trackTrip = Long.MIN_VALUE
    @Volatile private var trackLoading = false

    val connected: Boolean get() = lastRxAt != 0L && SystemClock.elapsedRealtime() - lastRxAt < 2000

    private val wifiCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) { network = n }
        override fun onLost(n: Network) { if (network == n) network = null }
    }
    // ---- интернет для карты (v1.6) ----
    // Wi-Fi «Krenometr» без интернета, но если на вопрос Android ответили «оставаться подключённым»,
    // система делает его сетью по умолчанию — и карта пытается грузиться через кренометр.
    // Поэтому всё, что не к кренометру (тайлы карты), привязываем к сети с настоящим интернетом:
    // мобильной (SIM), а если её нет — к любой проверенной системой (VALIDATED) сети.
    @Volatile var inetNet: Network? = null; private set
    @Volatile var inetLabel = "проверяю…"; private set
    private val validated = LinkedHashMap<Network, Boolean>()      // сеть → это мобильная?
    private var cellNet: Network? = null

    private fun pickInternet() {
        val pick = cellNet ?: synchronized(validated) { validated.entries.firstOrNull { it.value }?.key ?: validated.keys.firstOrNull() }
        if (pick != inetNet) {
            inetNet = pick
            try { cm.bindProcessToNetwork(pick) } catch (e: Exception) { }
        }
        inetLabel = when {
            pick == null -> "нет"
            pick == cellNet -> "SIM"
            synchronized(validated) { validated[pick] == true } -> "SIM"
            else -> "Wi-Fi/другая сеть"
        }
    }

    private val cellCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) { cellNet = n; pickInternet() }
        override fun onLost(n: Network) { if (cellNet == n) { cellNet = null; pickInternet() } }
    }
    private val validCb = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(n: Network, caps: NetworkCapabilities) {
            val ok = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            synchronized(validated) {
                if (ok) validated[n] = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) else validated.remove(n)
            }
            pickInternet()
        }
        override fun onLost(n: Network) { synchronized(validated) { validated.remove(n) }; pickInternet() }
    }

    private val directCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(n: Network) { network = n }
        override fun onLost(n: Network) { if (network == n) network = null }
    }

    fun start() {
        if (running) return
        running = true
        try {
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            cm.requestNetwork(req, wifiCb)
        } catch (e: Exception) {
            findWifiNow()
        }
        try {
            cm.requestNetwork(NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build(), cellCb)
        } catch (e: Exception) { }
        try {
            cm.registerNetworkCallback(NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                .build(), validCb)
        } catch (e: Exception) { }
        usb.start()
        val t = Thread({ loop() }, "kren-udp")
        t.isDaemon = true
        t.start()
        thread = t
    }

    fun stop() {
        running = false
        usb.stop()
        try { cm.unregisterNetworkCallback(wifiCb) } catch (e: Exception) { }
        try { cm.unregisterNetworkCallback(cellCb) } catch (e: Exception) { }
        try { cm.unregisterNetworkCallback(validCb) } catch (e: Exception) { }
        try { cm.bindProcessToNetwork(null) } catch (e: Exception) { }
        inetNet = null; cellNet = null
        synchronized(validated) { validated.clear() }
        if (directRequested) {
            try { cm.unregisterNetworkCallback(directCb) } catch (e: Exception) { }
            directRequested = false
        }
        thread?.interrupt()
        thread = null
    }

    /** Android 10+: подключиться к «Krenometr» силами приложения (система спросит разрешение). */
    fun connectDirect(): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        if (directRequested) return true
        return try {
            val spec = WifiNetworkSpecifier.Builder().setSsid(SSID).setWpa2Passphrase(PASS).build()
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build()
            cm.requestNetwork(req, directCb)
            directRequested = true
            true
        } catch (e: Exception) { false }
    }

    private fun findWifiNow() {
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) { network = n; return }
        }
    }

    // ---------------- поток данных ----------------
    private fun loop() {
        var sock: DatagramSocket? = null
        var boundTo: Network? = null
        var lastHello = 0L
        var helloWheels = false
        var lastLegacy = 0L
        var legacyN = 0L
        val buf = ByteArray(2048)
        val host = InetAddress.getByName(HOST)
        while (running) {
            try {
                val net = network
                if (sock == null || boundTo != net) {
                    sock?.close()
                    val s = DatagramSocket()
                    s.soTimeout = 100
                    if (net != null) try { net.bindSocket(s) } catch (e: Exception) { }
                    sock = s
                    boundTo = net
                    lastHello = 0L
                }
                udpSock = sock
                val now = SystemClock.elapsedRealtime()
                val ww = wantWheels
                val helloDue = now - lastHello >= 1000 || ww != helloWheels
                if (helloDue) {
                    lastHello = now
                    helloWheels = ww
                    // по кабелю — всегда, если он открыт; по Wi-Fi — только когда кабель молчит
                    if (usb.open) usb.write("K1 w=" + (if (ww) 1 else 0) + "\n")
                    if (!usbLive) {
                        val msg = ("K1 w=" + (if (ww) 1 else 0)).toByteArray()
                        sock.send(DatagramPacket(msg, msg.size, host, UDP_PORT))
                    }
                }
                if (usbLive) { Thread.sleep(50); continue }
                try {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val txt = String(p.data, 0, p.length, Charsets.UTF_8)
                    onSnap(Snap.parse(JSONObject(txt)))
                } catch (e: SocketTimeoutException) {
                    // пакета нет — ниже проверим старую прошивку
                }
                // Нет UDP 3 с — возможно, прошивка 3.9: читаем /a (около 5 раз в секунду, без колёс)
                val t = SystemClock.elapsedRealtime()
                val legacyNow = snap?.legacy != false          // ещё ничего не было или старая прошивка
                if ((t - lastRxAt > 3000 || legacyNow) && t - lastLegacy > 200) {
                    lastLegacy = t
                    val a = try { http("/a", 800) } catch (e: Exception) { null }
                    val udpFresh = snap?.legacy == false && SystemClock.elapsedRealtime() - lastRxAt < 1500
                    if (a != null && !udpFresh) {
                        try { onSnap(Snap.parseLegacy(JSONObject(a), legacyN++)) } catch (e: Exception) { }
                    }
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                try { sock?.close() } catch (x: Exception) { }
                sock = null
                try { Thread.sleep(500) } catch (x: InterruptedException) { break }
            }
        }
        try { sock?.close() } catch (e: Exception) { }
        udpSock = null
    }

    // ---------------- USB: строки от кренометра ----------------
    private fun onUsbLine(s: String) {
        if (s.startsWith("{")) {
            val sn = try { Snap.parse(JSONObject(s)) } catch (e: Exception) { return }
            usbLastRx = SystemClock.elapsedRealtime()
            onSnap(sn)
        } else if (s.startsWith("R")) {
            val sp = s.indexOf(' ')
            if (sp < 2) return
            val id = s.substring(1, sp).toIntOrNull() ?: return
            val body = unescape(s.substring(sp + 1))
            synchronized(usbLock) { usbReplies[id] = body; usbLock.notifyAll() }
        }
        // остальное — отладочный вывод прошивки, пропускаем
    }

    private fun unescape(t: String): String {
        val b = StringBuilder(t.length)
        var i = 0
        while (i < t.length) {
            val c = t[i]
            if (c == '\\' && i + 1 < t.length) {
                val d = t[i + 1]
                b.append(if (d == 'n') '\n' else d)
                i += 2
            } else { b.append(c); i++ }
        }
        return b.toString()
    }

    private fun usbRequest(path: String, timeoutMs: Int): String? {
        val id: Int
        synchronized(usbLock) { id = ++usbReqId }
        if (!usb.write("Q$id $path\n")) return null
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        synchronized(usbLock) {
            while (true) {
                usbReplies.remove(id)?.let { return it }
                val left = deadline - SystemClock.elapsedRealtime()
                if (left <= 0) return null
                usbLock.wait(left)
            }
        }
    }

    // ---------------- GPS магнитолы → кренометр ----------------
    /** bearing — курс движения по GPS, °, или −1 (стоим / нет курса). */
    fun sendGps(lat: Double, lon: Double, acc: Float, speedMs: Float, bearing: Float) {
        val line = String.format(java.util.Locale.US, "G1 %.7f %.7f %.1f %.2f %.1f", lat, lon, acc, speedMs, bearing)
        gpsIo.execute {
            try {
                if (usbLive) usb.write(line + "\n")
                else {
                    val s = udpSock ?: return@execute
                    val b = line.toByteArray()
                    s.send(DatagramPacket(b, b.size, InetAddress.getByName(HOST), UDP_PORT))
                }
            } catch (e: Exception) { }
        }
    }

    private fun onSnap(s: Snap) {
        val wasConnected = connected
        val prev = snap
        snap = s
        lastRxAt = SystemClock.elapsedRealtime()
        if (!wasConnected) onConnected()
        if (s.legacy) return
        // если пришёл UDP-пакет после старой прошивки — трек загрузить заново
        if (prev == null || prev.legacy || s.tripId != trackTrip) loadTrack()
        else if (!trackLoading) appendTrack(s.x, s.y)
    }

    private fun onConnected() {
        trackTrip = Long.MIN_VALUE                       // кренометр мог перезагрузиться — трек перечитать
        sendTime()
        async("/info") { r -> if (r != null) fwInfo = r }
    }

    fun sendTime() {
        val ms = System.currentTimeMillis()
        val e = (ms + TimeZone.getDefault().getOffset(ms)) / 1000
        async("/t?e=$e", null)
    }

    // ---------------- трек ----------------
    private fun loadTrack() {
        if (trackLoading) return
        trackLoading = true
        trackIo.execute {
            try {
                val r = http("/trk", 5000)
                if (r != null) {
                    val lines = r.split('\n')
                    val head = lines.firstOrNull()?.trim()?.split(' ')
                    val tid = head?.getOrNull(0)?.toLongOrNull()
                    if (tid != null) {
                        val xs = ArrayList<Float>(); val ys = ArrayList<Float>()
                        for (i in 1 until lines.size) {
                            val p = lines[i].trim().split(' ')
                            if (p.size < 2) continue
                            val x = p[0].toFloatOrNull() ?: continue
                            val y = p[1].toFloatOrNull() ?: continue
                            xs.add(x); ys.add(y)
                        }
                        synchronized(trackLock) {
                            ensureCap(xs.size + 64)
                            for (i in xs.indices) { trackX[i] = xs[i]; trackY[i] = ys[i] }
                            trackN = xs.size
                        }
                        trackTrip = tid
                    }
                }
            } catch (e: Exception) {
            } finally {
                trackLoading = false
            }
        }
    }

    private fun appendTrack(x: Float, y: Float) {
        synchronized(trackLock) {
            if (trackN > 0) {
                val dx = x - trackX[trackN - 1]; val dy = y - trackY[trackN - 1]
                if (hypot(dx, dy) < TRACK_STEP_M) return
            }
            ensureCap(trackN + 1)
            trackX[trackN] = x; trackY[trackN] = y; trackN++
        }
    }

    private fun ensureCap(n: Int) {
        if (n <= trackX.size) return
        var c = trackX.size
        while (c < n) c *= 2
        trackX = trackX.copyOf(c); trackY = trackY.copyOf(c)
    }

    // ---------------- HTTP ----------------
    fun http(path: String, timeoutMs: Int = 2000): String? {
        if (usbLive) return usbRequest(path, timeoutMs)
        val url = URL("http://$HOST$path")
        val net = network
        val c = (if (net != null) net.openConnection(url) else url.openConnection()) as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs
        c.useCaches = false
        try {
            if (c.responseCode != 200) return null
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Запрос в фоне; ответ (или null) — в главном потоке. */
    fun async(path: String, cb: ((String?) -> Unit)?) {
        io.execute {
            val r = try { http(path) } catch (e: Exception) { null }
            if (cb != null) main.post { cb(r) }
        }
    }

    // ---------------- терминал ELM327 через кренометр ----------------
    fun termSend(cmd: String, out: (String) -> Unit) {
        io.execute {
            val res = try { termRun(cmd) } catch (e: Exception) { "(ошибка: ${e.message})" }
            main.post { out(res) }
        }
    }

    private fun termRun(cmd: String): String {
        val r = http("/cmd?c=" + URLEncoder.encode(cmd, "UTF-8"))?.trim()
            ?: return "(нет связи с кренометром)"
        if (r == "busy") return "(кренометр занят предыдущей командой)"
        val ts = r.toLongOrNull() ?: return "(непонятный ответ: $r)"
        val t0 = SystemClock.elapsedRealtime()
        while (SystemClock.elapsedRealtime() - t0 < 15000) {
            Thread.sleep(250)
            val x = try { http("/cmdr") } catch (e: Exception) { null } ?: continue
            val i = x.indexOf('\n')
            if (i < 0) continue
            val n = x.substring(0, i).trim().toLongOrNull() ?: continue
            if (n > ts) {
                return x.substring(i + 1).split('\n').map { it.trim() }.filter { it.isNotEmpty() }
                    .joinToString("\n").ifEmpty { "(пусто)" }
            }
        }
        return "(нет ответа за 15 с)"
    }

    fun termEnd() = async("/cmdend", null)
}
