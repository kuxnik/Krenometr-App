plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.diy.krenometr"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.diy.krenometr"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "1.6"
    }

    // Тот же постоянный ключ, что у терминала: обновления ставятся поверх, без удаления.
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    // карта на экране «Трек»: тайлы, кэш, офлайн-архивы .mbtiles
    implementation("org.osmdroid:osmdroid-android:6.1.20")
}
